// Klik op het icoon: vraag de content script het paneel te openen.
// Is de script er nog niet (pagina was al open voor de installatie), dan eerst injecteren.
chrome.action.onClicked.addListener(tab => {
  if (!tab.id) return;
  const open = cb => chrome.tabs.sendMessage(tab.id, { t: 'open' }, res => {
    const err = chrome.runtime.lastError;
    cb && cb(!err && res && res.ok);
  });
  open(ok => {
    if (ok) return;
    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] })
      .then(() => setTimeout(() => open(), 200))
      .catch(() => {});
  });
});
