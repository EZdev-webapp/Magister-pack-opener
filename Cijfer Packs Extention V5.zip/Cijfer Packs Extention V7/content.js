(() => {
  if (window.__cijferPacks) return;
  window.__cijferPacks = true;
  if (/^accounts\./i.test(location.hostname)) return; // geen knop op de loginpagina
  document.querySelectorAll('[data-cp-host],style[data-cp-style]').forEach(e => e.remove()); // oude UI na herladen extensie

  // [klasse, label, glowkleur, achtergrond, tekstkleur, emoji]
  const R = [
    ['common', 'COMMON', '#9aa0ae', 'linear-gradient(160deg,#aab0bd,#5d6372)', '#fff', '😐'],
    ['silver', 'SILVER', '#cfd4e3', 'linear-gradient(160deg,#e3e6ee,#8e95a8)', '#1b1d28', '🙂'],
    ['gold', 'GOLD', '#ffd84a', 'linear-gradient(160deg,#f7e08a,#c79a1d)', '#2b2000', '😎'],
    ['epic', 'EPIC', '#a66bff', 'linear-gradient(160deg,#7a4bff,#2a0f6e)', '#fff', '🔥'],
    ['legendary', 'LEGENDARY', '#ff6a3d', 'linear-gradient(160deg,#ff9a3d,#c0261a)', '#fff', '👑'],
    ['perfect', 'PERFECT', '#ff5fd2', 'linear-gradient(135deg,#ff4d4d,#ffb84d,#f4ff4d,#4dff88,#4dc3ff,#9b4dff,#ff4dd2)', '#1a0b33', '💎']
  ];
  const rar = g => g >= 10 ? R[5] : g >= 9 ? R[4] : g >= 8 ? R[3] : g >= 7 ? R[2] : g >= 5.5 ? R[1] : R[0];
  const num = s => parseFloat(String(s).replace(',', '.'));
  const fmt = n => { const r = Math.round(n * 100) / 100; return (Number.isInteger(r * 10) ? r.toFixed(1) : r.toFixed(2)).replace('.', ','); };
  const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const DNL = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
  const MON = { jan: 0, feb: 1, maa: 2, mrt: 2, apr: 3, mei: 4, jun: 5, jul: 6, aug: 7, sep: 8, okt: 9, nov: 10, dec: 11 };
  const isoD = (y, m, d) => { const t = new Date(y, m, d); return isNaN(t) ? null : t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0'); };
  function parseDate(lines) {
    const now = new Date();
    for (const l of lines) {
      let m = l.match(/\b(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4}|\d{2})\b/);
      if (m && +m[2] >= 1 && +m[2] <= 12 && +m[1] >= 1 && +m[1] <= 31) { let y = +m[3]; if (y < 100) y += 2000; return isoD(y, +m[2] - 1, +m[1]); }
      m = l.match(/\b(\d{1,2})\s+(jan|feb|maa|mrt|apr|mei|jun|jul|aug|sep|okt|nov|dec)[a-z]*\.?(?:\s+(\d{4}))?/i);
      if (m) {
        const mo = MON[m[2].toLowerCase()]; let y = m[3] ? +m[3] : now.getFullYear();
        if (!m[3] && new Date(y, mo, +m[1]) > new Date(now.getTime() + 7 * 864e5)) y--;
        return isoD(y, mo, +m[1]);
      }
    }
    return null;
  }
  const fmtDate = s => { if (!s) return ''; const p = s.split('-').map(Number); return p[2] + ' ' + DNL[p[1] - 1] + ' ' + p[0]; };
  const hash = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0; return String(h); };

  // ---------- opslag (alleen lokaal in je browser) ----------
  let opened = new Set(), muted = false, shieldOn = true;
  let cards = {}, squad = { f: '4-3-3', s: Array(11).fill(null) }, tab = 'packs', pickSlot = null;
  let mode = 'cin', streakMin = 7, statsAll = false, rec = null, PULL = null;
  const MODES = { cin: '🎬 Cinematic', quick: '⚡ Quick open', inst: '⏩ Instant' }, STK = [5.5, 6, 7, 8];
  const RM = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  const effMode = () => (RM.matches && mode === 'cin') ? 'quick' : mode;
  const store = {
    load: () => new Promise(r => { try { chrome.storage.local.get(['opened', 'prefs', 'cards', 'squad', 'rec'], d => r(d || {})); } catch (e) { r({}); } }),
    saveOpened: () => { try { chrome.storage.local.set({ opened: [...opened] }); } catch (e) {} },
    savePrefs: () => { try { chrome.storage.local.set({ prefs: { muted, shieldOn, mode, streakMin, statsAll } }); } catch (e) {} },
    saveCards: () => { try { chrome.storage.local.set({ cards }); } catch (e) {} },
    saveSquad: () => { try { chrome.storage.local.set({ squad }); } catch (e) {} },
    saveRec: () => { try { chrome.storage.local.set({ rec }); } catch (e) {} }
  };

  // alle gescande cijfers lokaal bewaren (ook datum/weging); 'opened' bepaalt wat onthuld is
  const syncCards = its => {
    let dirty = false;
    its.forEach(it => {
      const c = cards[it.id];
      if (!c) { cards[it.id] = { vak: it.vak, c: it.c, oms: it.oms, weging: it.weging, d: it.d }; dirty = true; return; }
      if (!c.d && it.d) { c.d = it.d; dirty = true; }
      if (!c.weging && it.weging) { c.weging = it.weging; dirty = true; }
    });
    if (dirty) store.saveCards();
  };

  // ---------- statistieken: één centrale laag, alles gebruikt dit ----------
  const f2 = n => n.toFixed(2).replace('.', ',');
  const fd = n => (n >= 0 ? '+' : '−') + Math.abs(n).toFixed(2).replace('.', ',');
  const wOf = g => { if (!g.weging) return null; const n = parseFloat(String(g.weging).replace(',', '.').replace(/[^\d.]/g, '')); return n > 0 ? n : null; };
  const avgOf = a => a.length ? a.reduce((x, g) => x + g.c, 0) / a.length : null;
  const wavgOf = a => { const w = a.filter(g => wOf(g)); if (!w.length) return null; const sw = w.reduce((x, g) => x + wOf(g), 0); return { v: w.reduce((x, g) => x + g.c * wOf(g), 0) / sw, n: w.length, sw }; };
  const allList = () => Object.keys(cards).map(id => Object.assign({ id }, cards[id]));
  const openedList = () => allList().filter(g => opened.has(g.id));
  const basisList = () => statsAll ? allList() : openedList();
  function computeStats(a, min) {
    const S = { n: a.length };
    if (!a.length) return S;
    min = min || 7;
    S.avg = avgOf(a); S.w = wavgOf(a);
    S.max = a.reduce((m, g) => g.c > m.c ? g : m, a[0]); S.min = a.reduce((m, g) => g.c < m.c ? g : m, a[0]);
    S.n7 = a.filter(g => g.c >= 7).length; S.n8 = a.filter(g => g.c >= 8).length; S.n9 = a.filter(g => g.c >= 9).length; S.n10 = a.filter(g => g.c >= 10).length;
    S.bands = [a.filter(g => g.c < 5.5).length, a.filter(g => g.c >= 5.5 && g.c < 7).length, a.filter(g => g.c >= 7 && g.c < 8).length, a.filter(g => g.c >= 8 && g.c < 9).length, a.filter(g => g.c >= 9 && g.c < 10).length, S.n10];
    S.rar = [0, 0, 0, 0, 0, 0]; a.forEach(g => S.rar[LV[rar(g.c)[0]]]++);
    const by = {}; a.forEach(g => (by[g.vak] = by[g.vak] || []).push(g));
    S.vakken = Object.keys(by).map(v => ({ v, n: by[v].length, avg: avgOf(by[v]), w: wavgOf(by[v]) })).sort((x, y) => y.avg - x.avg);
    const dated = a.filter(g => g.d).sort((x, y) => x.d < y.d ? -1 : x.d > y.d ? 1 : 0);
    S.dated = dated.length;
    let best = 0, run = 0; dated.forEach(g => { if (g.c >= min) { run++; if (run > best) best = run; } else run = 0; });
    let cur = 0; for (let i = dated.length - 1; i >= 0 && dated[i].c >= min; i--) cur++;
    S.streak = best; S.curStreak = cur;
    const mo = {}; dated.forEach(g => { const k = g.d.slice(0, 7); (mo[k] = mo[k] || []).push(g); });
    S.months = Object.keys(mo).sort().map(k => ({ k, n: mo[k].length, avg: avgOf(mo[k]) }));
    return S;
  }

  // ---------- geluid (alles gesynthetiseerd) ----------
  let AC = null, MG = null, COMP = null;
  const newBus = () => {
    if (!AC) return;
    const old = MG;
    if (old) { try { const t = AC.currentTime; old.gain.cancelScheduledValues(t); old.gain.setValueAtTime(old.gain.value, t); old.gain.linearRampToValueAtTime(0, t + 0.08); setTimeout(() => { try { old.disconnect(); } catch (e) {} }, 250); } catch (e) {} }
    MG = AC.createGain(); MG.gain.value = 1.6; MG.connect(COMP);
  };
  const killSound = () => newBus();
  const ac = () => {
    if (!AC) {
      try {
        AC = new (window.AudioContext || window.webkitAudioContext)();
        COMP = AC.createDynamicsCompressor(); COMP.connect(AC.destination);
        newBus();
      } catch (e) {}
    }
    if (AC && AC.state !== 'running') AC.resume().catch(() => {});
    return AC;
  };
  function tone(f, t0, d, type, v, f2) {
    const a = ac(); if (!a || muted) return;
    const T = a.currentTime + t0, o = a.createOscillator(), g = a.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, T);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, T + d);
    g.gain.setValueAtTime(0.0001, T); g.gain.exponentialRampToValueAtTime(v, T + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, T + d);
    o.connect(g); g.connect(MG); o.start(T); o.stop(T + d + 0.05);
  }
  function noise(t0, d, type, f1, f2, v) {
    const a = ac(); if (!a || muted) return;
    const n = (a.sampleRate * d) | 0, b = a.createBuffer(1, n, a.sampleRate), c = b.getChannelData(0);
    for (let i = 0; i < n; i++) c[i] = Math.random() * 2 - 1;
    const s = a.createBufferSource(); s.buffer = b;
    const f = a.createBiquadFilter(), g = a.createGain(), T = a.currentTime + t0;
    f.type = type; f.frequency.setValueAtTime(f1, T); f.frequency.exponentialRampToValueAtTime(f2, T + d);
    g.gain.setValueAtTime(0.0001, T); g.gain.exponentialRampToValueAtTime(v, T + d * 0.7); g.gain.exponentialRampToValueAtTime(0.0001, T + d);
    s.connect(f); f.connect(g); g.connect(MG); s.start(T);
  }
  const CH = {
    common: [196, 233], silver: [262, 330, 392], gold: [392, 494, 587, 784],
    epic: [330, 415, 494, 659, 988], legendary: [392, 494, 587, 784, 1047, 1319], perfect: [523, 659, 784, 1047, 1319, 1568]
  };
  const boom = () => { tone(140, 0, 0.5, 'sine', 0.5, 38); noise(0, 0.25, 'lowpass', 2000, 200, 0.25); };
  const snd = {
    whoosh() { noise(0, 0.55, 'bandpass', 300, 5000, 0.18); },
    cat(k) {
      boom(); CH[k].forEach((f, i) => tone(f, i * 0.06, 1.1, 'triangle', 0.14));
      if (k === 'epic' || k === 'legendary' || k === 'perfect') for (let i = 0; i < 6; i++) tone(1200 + i * 260, 0.15 + i * 0.07, 0.35, 'sine', 0.05);
    },
    final(k) {
      boom();
      if (k === 'common') { tone(330, 0, 0.8, 'sawtooth', 0.12, 120); return; }
      CH[k].forEach((f, i) => tone(f, i * 0.05, 1.5, 'triangle', 0.15));
      noise(0, 2, 'bandpass', 500, 900, k === 'gold' ? 0.07 : k === 'silver' ? 0.03 : 0.13);
      if (k === 'legendary' || k === 'perfect') [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, 0.3 + i * 0.08, 0.6, 'sine', 0.1));
      if (k === 'perfect') for (let i = 0; i < 10; i++) tone(1500 + i * 220, 0.7 + i * 0.07, 0.4, 'sine', 0.06);
    }
  };

  const LV = { common: 0, silver: 1, gold: 2, epic: 3, legendary: 4, perfect: 5 };
  Object.assign(snd, {
    blackout(L) { tone(55, 0, 1.6, 'sine', 0.22 + 0.03 * L, 38); },
    tunnel(ms, L) { const t = ms / 1000; noise(0, t, 'bandpass', 200, 2200 + L * 600, 0.16 + 0.03 * L); tone(90, 0, t, 'sawtooth', 0.05 + 0.01 * L, 500 + L * 90); },
    vak(L) { boom(); noise(0, 0.5, 'bandpass', 400, 6000, 0.2); tone(660, 0.05, 0.5, 'triangle', 0.12); if (L >= 3) tone(990, 0.1, 0.6, 'triangle', 0.08); },
    cardIn(ms, L) { const t = ms / 1000; tone(180, 0, t, 'triangle', 0.07 + 0.01 * L, 720); for (let i = 0; i < 4 + L; i++) tone(1200 + i * 180, t * 0.4 + i * 0.09, 0.3, 'sine', 0.035); },
    spin(ms, L) { const n = Math.max(2, Math.round(ms / 450)); for (let i = 0; i < n; i++) noise(i * ms / 1000 / n, 0.35, 'bandpass', 500, 2500, 0.08 + 0.01 * L); },
    tension(ms) { const t = ms / 1000; tone(70, 0, t, 'sawtooth', 0.09, 330); noise(0, t, 'highpass', 400, 5000, 0.1); for (let i = 0; i < 10; i++) tone(60, t * Math.pow(i / 10, 0.8), 0.18, 'sine', 0.3, 38); },
    flash(L) { noise(0, 0.7, 'highpass', 800, 9000, 0.12 + 0.04 * L); boom(); },
    digit(i, L) { tone(520 + i * 140, 0, 0.09, 'square', 0.05 + 0.01 * L); tone(1040 + i * 280, 0, 0.12, 'triangle', 0.05); },
    perfect() { [523, 659, 784, 1047, 1319, 1568, 2093].forEach((f, i) => tone(f, i * 0.09, 1.2, 'triangle', 0.12)); noise(0, 2.5, 'bandpass', 600, 1200, 0.16); for (let i = 0; i < 14; i++) tone(1800 + i * 160, 0.5 + i * 0.06, 0.35, 'sine', 0.05); boom(); tone(140, 0.3, 0.5, 'sine', 0.5, 38); }
  });

  Object.assign(snd, {
    ping() { tone(988, 0, .25, 'sine', .08); tone(1319, .09, .35, 'sine', .07); },
    record() { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, i * .09, .9, 'triangle', .13)); noise(0, 1.6, 'bandpass', 700, 2600, .1); for (let i = 0; i < 8; i++) tone(1600 + i * 200, .45 + i * .06, .3, 'sine', .05); boom(); }
  });

  // ---------- cijfers uit de pagina halen ----------
  const ROWSEL = 'tr,[role=row],li,[class*=grade],[class*=cijfer],[class*=Grade],[class*=Cijfer]';
  const EXCL = /^(gemiddeld\w*|gem\.?|eindcijfer|rapport\w*|totaal|weging|gewicht|cijfer|datum|vak|omschrijving|periode|resultaat)\b/i;
  const AVGL = /^(gemiddeld\w*|gem\.?|eindcijfer|rapport\w*|totaal)\s*:?\s*[\d.,]*$/i;
  const isGrade = l => /^\d{1,2}([.,]\d{1,2})?$/.test(l) && num(l) >= 1 && num(l) <= 10;
  let avgRows = []; // rijen met gemiddelden of dubbelzinnige getallen: worden mee verborgen
  function scan() {
    const cands = []; avgRows = [];
    document.querySelectorAll(ROWSEL).forEach(el => {
      if (host.contains(el)) return;
      if (el.querySelector('tr,[role=row],li')) return;
      const lines = (el.innerText || '').split(/\n+/).map(s => s.trim()).filter(Boolean);
      if (lines.length < 2 || lines.length > 14) return;
      if (lines.some(l => AVGL.test(l))) { avgRows.push(el); return; }
      const grades = lines.filter((l, i) => isGrade(l) && !(i > 0 && /weging|gewicht|periode/i.test(lines[i - 1])));
      if (grades.length > 1) { avgRows.push(el); return; }
      if (grades.length !== 1) return;
      const vak = lines.find(l => /[A-Za-zÀ-ÿ]{3}/.test(l) && !/^\d/.test(l) && l.length <= 45 && !EXCL.test(l));
      if (!vak) return;
      const wl = lines.find(l => /^\d+([.,]\d+)?\s*[x×]$/i.test(l));
      const oms = lines.find(l => l !== vak && !/^\d/.test(l) && /[A-Za-zÀ-ÿ]{3}/.test(l) && l.length <= 60 && !EXCL.test(l));
      cands.push({ vak, c: Math.round(num(grades[0]) * 100) / 100, el, gs: grades[0], oms: oms || '', weging: wl ? wl.replace(/\s*[x×]/i, '×') : '', d: parseDate(lines) });
    });
    const kept = cands.filter(a => !cands.some(b => b !== a && b.el.contains(a.el)));
    const cnt = {};
    kept.forEach(it => { const k = it.vak + '|' + it.gs + '|' + it.oms; cnt[k] = (cnt[k] || 0) + 1; it.id = hash(k + '|' + cnt[k]); });
    return kept;
  }

  // ---------- spoilerbescherming ----------
  const css = document.createElement('style');
  css.setAttribute('data-cp-style', '');
  css.textContent = '[data-cp-hide],[data-cp-hide] *{color:transparent!important;text-shadow:none!important;user-select:none!important}' +
    '[data-cp-hide]{background:#8a8f9e66!important;border-radius:6px!important}';
  document.head.appendChild(css);
  const hide = n => n.setAttribute('data-cp-hide', '');
  function leafHide(el) {
    el.querySelectorAll('*').forEach(n => {
      if (n.children.length) return;
      const t = n.textContent.trim();
      if (isGrade(t) || (t.length <= 24 && /\b\d{1,2}[.,]\d{1,2}\b/.test(t))) hide(n);
    });
  }
  function shield() {
    document.querySelectorAll('[data-cp-hide]').forEach(e => e.removeAttribute('data-cp-hide'));
    if (!shieldOn) return;
    const its = scan();
    syncCards(its);
    its.forEach(it => {
      if (opened.has(it.id)) return;
      it.el.querySelectorAll('*').forEach(n => { if (!n.children.length && n.textContent.trim() === it.gs) hide(n); });
    });
    // gemiddelden verraden het cijfer: verborgen zolang er nog een pack dicht is
    if (its.some(i => !opened.has(i.id))) avgRows.forEach(leafHide);
  }
  // snelle pass op nieuwe nodes (vóór de paint), de volledige scan corrigeert daarna
  function fastHide(n) {
    if (!n) return;
    if (n.nodeType === 3) n = n.parentElement;
    if (!n || n.nodeType !== 1 || n === host || host.contains(n)) return;
    const test = e => { if (!e.children.length && isGrade(e.textContent.trim()) && e.closest(ROWSEL)) hide(e); };
    test(n);
    n.querySelectorAll('*').forEach(test);
  }
  let last = 0, pend = 0;
  new MutationObserver(muts => {
    if (!shieldOn) return;
    for (const m of muts) { if (m.type === 'characterData') fastHide(m.target); else m.addedNodes.forEach(fastHide); }
    if (pend) return;
    pend = setTimeout(() => { pend = 0; last = Date.now(); shield(); }, Math.max(120, 300 - (Date.now() - last)));
  }).observe(document.body, { childList: true, subtree: true, characterData: true });

  // ---------- pack-tekening (goudfolie met gekartelde randen) ----------
  let d = 'M8 14';
  for (let x = 14, i = 1; x <= 172; x += 6, i++) d += ` L${x} ${i % 2 ? 7 : 14}`;
  d += ' L172 36 Q164 44 164 60 L164 200 Q164 216 172 224 L172 246';
  for (let x = 166, i = 1; x >= 8; x -= 6, i++) d += ` L${x} ${i % 2 ? 253 : 246}`;
  d += ' L8 224 Q16 216 16 200 L16 60 Q16 44 8 36 Z';
  const DEFS = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <linearGradient id="gold" x1="0" y1="0" x2="0.35" y2="1">
      <stop offset="0" stop-color="#f7de8c"/><stop offset=".35" stop-color="#e2c273"/><stop offset=".7" stop-color="#b79448"/><stop offset="1" stop-color="#7c6130"/>
    </linearGradient>
    <linearGradient id="sheen" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#fff" stop-opacity=".38"/><stop offset="1" stop-color="#fff" stop-opacity="0"/>
    </linearGradient>
    <pattern id="cr" width="6" height="6" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="#d8ba68"/><path d="M0 3L3 0L6 3L3 6Z" fill="#b8994a"/></pattern>
    <clipPath id="shape"><path d="${d}"/></clipPath>
    <symbol id="pk" viewBox="0 0 180 260">
      <path d="${d}" fill="url(#gold)"/>
      <g clip-path="url(#shape)">
        <rect x="0" y="0" width="180" height="36" fill="url(#cr)"/>
        <rect x="0" y="224" width="180" height="40" fill="url(#cr)"/>
        <rect x="0" y="35" width="180" height="2" fill="#8a6d2a" opacity=".6"/>
        <rect x="0" y="223" width="180" height="2" fill="#8a6d2a" opacity=".6"/>
        <g fill="#6f5522" opacity=".13">
          <polygon points="30,60 85,60 62,130 20,130"/><polygon points="100,66 155,66 155,104 122,104"/>
          <polygon points="40,160 92,150 72,212 30,212"/><polygon points="110,150 158,162 142,214 104,204"/>
        </g>
        <rect x="16" y="38" width="46" height="186" fill="url(#sheen)"/>
      </g>
      <circle cx="90" cy="130" r="42" fill="none" stroke="#fff" stroke-width="5"/>
      <text x="90" y="144" text-anchor="middle" font-family="'Arial Black',Arial,sans-serif" font-weight="900" font-style="italic" font-size="36" fill="#fff">CP</text>
    </symbol></defs></svg>`;
  const PK = '<svg viewBox="0 0 180 260"><use href="#pk"/></svg>';

  // ---------- hulpjes voor de filmische opening ----------
  const rgb = h => { h = h.replace('#', ''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const rgba = (h, a) => { const c = rgb(h); return `rgba(${c[0]},${c[1]},${c[2]},${a})`; };
  const PAL = {
    common: ['#cfd3de', '#8d93a3', '#ffffff'], silver: ['#ffffff', '#dfe6ff', '#aab8ff'],
    gold: ['#fff3a0', '#ffd84a', '#f3a81a', '#ffffff'], epic: ['#c9a3ff', '#a66bff', '#ff7ad9', '#ffffff'],
    legendary: ['#ff6a3d', '#ffb347', '#ff3b3b', '#fff2c4'],
    perfect: ['#ff4d4d', '#ffb84d', '#f4ff4d', '#4dff88', '#4dc3ff', '#9b4dff', '#ff4dd2', '#ffffff']
  };
  const TC = {
    common:    { tun: 1000, vak: 1200, card: 1300, rar: 0,    dig: 170, n: 30,  shake: 0,  ray: .15, bo: 300,  tint: .05, fl: .3,  gmax: 18 },
    silver:    { tun: 1700, vak: 1500, card: 1800, rar: 700,  dig: 210, n: 80,  shake: 0,  ray: .3,  bo: 500,  tint: .12, fl: .45, gmax: 36 },
    gold:      { tun: 2100, vak: 1800, card: 2100, rar: 1000, dig: 270, n: 150, shake: 6,  ray: .45, bo: 600,  tint: .2,  fl: .6,  gmax: 55 },
    epic:      { tun: 2500, vak: 2000, card: 2600, rar: 1200, dig: 330, n: 240, shake: 10, ray: .6,  bo: 700,  tint: .3,  fl: .75, gmax: 75,  zoom: 1.08 },
    legendary: { tun: 2900, vak: 2100, card: 3400, rar: 1500, dig: 430, n: 400, shake: 16, ray: .85, bo: 1200, tint: .4,  fl: 1,   gmax: 105, zoom: 1.12, dark: 1, stream: 1 },
    perfect:   { tun: 3200, vak: 2200, card: 3600, rar: 1900, dig: 520, n: 520, shake: 18, ray: 1,   bo: 1400, tint: .45, fl: 1,   gmax: 125, zoom: 1.14, dark: 1, stream: 1 }
  };
  const EMO = [['nederlands', '🇳🇱'], ['engels', '🇬🇧'], ['frans', '🇫🇷'], ['duits', '🇩🇪'], ['spaans', '🇪🇸'], ['wiskunde', '📐'], ['natuurkunde', '⚛️'],
    ['scheikunde', '🧪'], ['biologie', '🧬'], ['geschiedenis', '🏛️'], ['aardrijkskunde', '🌍'], ['economie', '💶'], ['lichamelijk', '🏃'], ['informatica', '💻'],
    ['muziek', '🎵'], ['tekenen', '🎨'], ['kunst', '🎨'], ['maatschappij', '🧑‍🤝‍🧑'], ['latijn', '🏺'], ['grieks', '🏺'], ['bewegings', '🏃'], ['nask', '⚛️'], ['ckv', '🎨'], ['bedrijfs', '💶'], ['filosofie', '🤔'], ['mentor', '🧭'], ['levensbeschouwing', '🕊️']];
  const emo = v => { v = v.toLowerCase(); const m = EMO.find(e => v.includes(e[0])); return m ? m[1] : '📚'; };

  // ---------- UI in shadow DOM ----------
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;z-index:2147483647;inset:auto 18px 18px auto;';
  host.setAttribute('data-cp-host', '');
  document.body.appendChild(host);
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = DEFS + `
<style>
*{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
button{font-family:inherit}
#fab{background:#5b5bf0;color:#fff;border:0;border-radius:999px;padding:12px 18px;font-weight:700;font-size:15px;cursor:pointer;box-shadow:0 6px 24px #0006}
#panel{position:fixed;inset:0;background:#05060cb8;backdrop-filter:blur(3px);display:none;align-items:center;justify-content:center;padding:16px}
#panel.on{display:flex}
.modal{position:relative;width:min(96vw,max(640px,72vw));max-width:980px;max-height:90vh;overflow:auto;background:#0f1220;border:1px solid #262a3b;border-radius:20px;color:#fff;padding:18px 22px 22px;box-shadow:0 20px 80px #000a}
.hd{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:10px;position:relative}
.hd h2{margin:0;font-size:19px}
.cnt{font-size:14px;color:#c9cde0;font-weight:600;text-align:center}
.ic{display:flex;gap:6px;justify-content:flex-end}
.ib{width:36px;height:36px;border-radius:10px;border:1px solid #262a3b;background:#171a27;color:#cfd3e6;font-size:16px;cursor:pointer}
.ib:hover{background:#20243a}
.bar{height:8px;background:#1b1f31;border-radius:99px;margin:12px 0 18px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#f3c13a,#ffe27a);border-radius:99px;transition:width .8s}
#toast{position:sticky;top:0;z-index:4;margin:-6px auto 10px;width:max-content;max-width:100%;background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;font-weight:800;padding:8px 16px;border-radius:99px;box-shadow:0 0 24px #f3c13a88;opacity:0;transform:translateY(-8px);transition:.4s;pointer-events:none;height:0;overflow:hidden;padding-top:0;padding-bottom:0}
#toast.on{opacity:1;transform:none;height:auto;padding-top:8px;padding-bottom:8px}
#menu{display:none;position:absolute;top:44px;right:0;z-index:5;background:#171a27;border:1px solid #2c3148;border-radius:12px;padding:6px;min-width:240px;box-shadow:0 10px 30px #000a}
#menu.on{display:block}
.mi{display:block;width:100%;text-align:left;background:none;border:0;color:#e4e7f5;padding:9px 10px;border-radius:8px;font-size:14px;cursor:pointer}
.mi:hover{background:#20243a}.mi.dng{color:#ff7a7a}
#menu hr{border:0;border-top:1px solid #2c3148;margin:6px 0}
.hero{position:relative;display:flex;align-items:center;justify-content:center;gap:34px;padding:22px 18px;border-radius:18px;margin-bottom:20px;overflow:hidden;background:radial-gradient(circle at 28% 50%,#4a3a12 0,#171a2a 62%);border:1px solid #6b5522}
.pw{position:relative;width:128px;flex:none;cursor:pointer;animation:bob 3s ease-in-out infinite;filter:drop-shadow(0 0 24px #f3c13aa0)}
.pw svg{width:100%;display:block}
@keyframes bob{50%{transform:translateY(-8px) rotate(1.5deg)}}
.sp{position:absolute;font-size:18px;opacity:0;animation:tw 2.2s infinite;pointer-events:none}
.s1{top:-8px;right:-14px}.s2{bottom:30px;left:-18px;animation-delay:.7s;font-size:14px}.s3{top:60px;right:-22px;animation-delay:1.4s;font-size:12px}.s4{top:-6px;left:10px;animation-delay:1.9s;font-size:13px}
@keyframes tw{0%,100%{opacity:0;transform:scale(.4) rotate(0)}50%{opacity:1;transform:scale(1.1) rotate(20deg)}}
.info small{color:#e7cf85;letter-spacing:.14em;font-size:12px;font-weight:700;text-transform:uppercase}
.info h3{margin:4px 0 0;font-size:30px}
.info .q{font-size:42px;font-weight:900;letter-spacing:.2em;color:#ffffff40;margin:2px 0 10px}
.big{border:0;border-radius:12px;padding:14px 28px;font-size:16px;font-weight:900;letter-spacing:.04em;background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;cursor:pointer;box-shadow:0 0 26px #f3c13a88;animation:pulse 2s infinite}
.big:hover{filter:brightness(1.1)}
@keyframes pulse{50%{box-shadow:0 0 42px #f3c13acc;transform:scale(1.03)}}
.info .left{margin-top:10px;font-size:13px;color:#9aa0c0}
.hero.done{flex-direction:column;gap:6px;text-align:center}.hero.done b{font-size:22px}
.ct{font-size:13px;color:#9aa0c0;font-weight:700;letter-spacing:.1em;text-transform:uppercase;margin-bottom:10px}
.empty{color:#9aa0c0;text-align:center;padding:30px 10px;line-height:1.5}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(118px,1fr));gap:12px;padding:6px 4px}
.it{position:relative;background:#161a29;border:1px solid #262a3b;border-radius:14px;padding:10px;text-align:center;transition:transform .15s,box-shadow .15s,border-color .15s}
.it svg{height:92px;width:auto;display:block;margin:0 auto}
.it .lb{font-size:12px;color:#9aa0c0;margin:6px 0 8px}
.it.cl:hover{transform:translateY(-3px);box-shadow:0 8px 22px #f3c13a30;border-color:#8a6d22}
.sm{width:100%;padding:7px;border-radius:9px;border:1px solid #3a3e66;background:#20243a;color:#fff;font-weight:600;font-size:13px;cursor:pointer}
.ar{display:none}.it.cl:hover .ar{display:inline}
.it.active{border-color:#f3c13a;box-shadow:0 0 22px #f3c13a55;transform:scale(1.04)}
.it.active:hover{transform:scale(1.06) translateY(-3px)}
.it.active .sm{background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;border:0;font-weight:800}
.it.active .spk{position:absolute;top:-8px;right:-4px;animation:tw 2s infinite}
.it.op{cursor:pointer;min-height:136px;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:10px 8px;border:0}
.it.op:hover{transform:translateY(-2px)}
.it.op.new{animation:newc 1.6s ease-out}
@keyframes newc{0%{transform:scale(.4) rotate(-6deg);opacity:0;box-shadow:0 0 0 #fff}40%{transform:scale(1.18);opacity:1;box-shadow:0 0 50px #ffe27a}100%{transform:none;box-shadow:0 0 0 transparent}}
.it.op .vk{font-size:12px;font-weight:800;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.it.op .gn{font-size:36px;font-weight:900;line-height:1}
.badge{font-size:10px;font-weight:800;letter-spacing:.14em;padding:2px 9px;border-radius:99px;background:#0003}
.it.op .ck{font-size:10px;opacity:.75;letter-spacing:.08em}

/* ===== elftal ===== */
.tabs{display:flex;gap:6px;margin:14px 0 4px}
.tab{flex:1;padding:10px;border-radius:10px;border:1px solid #262a3b;background:#171a27;color:#cfd3e6;font-weight:700;font-size:14px;cursor:pointer}
.tab.on{background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;border:0}
.sqtop{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin:14px 0}
.avg{display:flex;flex-direction:column;padding:10px 20px;border-radius:14px;min-width:170px;box-shadow:0 0 22px #0006}
.avg small{font-size:11px;letter-spacing:.14em;font-weight:800;opacity:.8}
.avg b{font-size:42px;line-height:1.1;font-weight:900}
.avg span{font-size:12px;font-weight:600;opacity:.85}
.sqctl{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.sqctl select,.sqctl button{border-radius:10px;padding:9px 14px;font-weight:700;font-size:13px;cursor:pointer;border:1px solid #3a3e66;background:#171a2b;color:#fff}
.sqctl button.pri{background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;border:0}
.pitch{position:relative;width:100%;max-width:520px;aspect-ratio:68/80;margin:0 auto;border-radius:14px;border:3px solid #ffffff88;background:repeating-linear-gradient(0deg,#1d7a3b 0 12.5%,#228a43 12.5% 25%);overflow:hidden}
.pitch::before{content:'';position:absolute;left:0;right:0;top:50%;border-top:2px solid #ffffff77}
.pitch::after{content:'';position:absolute;left:50%;top:50%;width:24%;aspect-ratio:1;border:2px solid #ffffff77;border-radius:50%;transform:translate(-50%,-50%)}
.bx{position:absolute;left:25%;width:50%;height:15%;border:2px solid #ffffff77}
.bx.t{top:-2px;border-top:0}.bx.b{bottom:-2px;border-bottom:0}
.slot{position:absolute;transform:translate(-50%,-50%);width:15%;min-width:50px;aspect-ratio:3/4;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 4px 12px #0007;z-index:1;transition:transform .15s}
.slot:hover{transform:translate(-50%,-50%) scale(1.1)}
.slot b{font-size:clamp(14px,3.4vw,20px);line-height:1;font-weight:900}
.slot span{font-size:clamp(8px,1.8vw,10px);font-weight:800;max-width:92%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:3px}
.slot.em{background:#0004;border:2px dashed #ffffff88;color:#fff;box-shadow:none}
.slot.em b{font-size:22px;opacity:.8}
.it.sel{outline:3px solid #ffe27a}
.sqb{margin-top:14px}
.sqhint{text-align:center;font-size:12px;color:#9aa0c0;margin-top:10px}

/* ===== v7: stats, historie, resultaat ===== */
.tab{white-space:nowrap;padding:10px 4px;font-size:13px}
#rstrip{display:flex;flex-wrap:wrap;gap:6px;margin:-8px 0 14px}
.rc{border:1px solid;border-radius:99px;padding:3px 10px;font-size:11px;font-weight:800;letter-spacing:.06em;background:#ffffff08}
.rc.best{border-color:#ffe27a;color:#ffe27a}
.sbasis{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:14px 0 6px}
.sbasis button{padding:8px 12px;border-radius:99px;border:1px solid #3a3e66;background:#171a2b;color:#cfd3e6;font-weight:700;font-size:13px;cursor:pointer}
.sbasis button.on{background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;border:0}
.snote{font-size:12px;color:#9aa0c0;line-height:1.5;margin:4px 0 12px}.snote.warn{color:#ffb86b}
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:10px 0}
.sc{background:#151a2d;border:1px solid #262a3b;border-radius:14px;padding:12px 14px}
.sc small{display:block;font-size:10px;letter-spacing:.14em;font-weight:800;color:#9aa4d8}
.sc b{display:block;font-size:28px;font-weight:900;line-height:1.15;margin-top:4px}
.sc.big b{font-size:38px}.sc.na b{font-size:15px;color:#9aa0c0;font-weight:700}
.sc span{display:block;font-size:12px;color:#aeb4d6;margin-top:2px}
.sh{font-size:14px;font-weight:800;margin:22px 0 8px}
.bars{display:flex;flex-direction:column;gap:6px}
.br{display:grid;grid-template-columns:minmax(80px,30%) 1fr auto;gap:8px;align-items:center;font-size:13px}
.br .nm{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.br .nm small{color:#9aa4d8}
.br .trk{height:12px;background:#1b1f31;border-radius:99px;overflow:hidden}
.br .trk i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#6a7cff,#a66bff)}
.br .vl{font-weight:800;min-width:54px;text-align:right}
.hl{display:flex;flex-direction:column;gap:6px}
.hr{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:12px;background:#151a2d;border:1px solid #262a3b;cursor:pointer}
.hr:hover{border-color:#8a6d22}
.hr .g{min-width:56px;text-align:center;font-weight:900;font-size:18px;border-radius:8px;padding:4px 6px}
.hr .m{flex:1;min-width:0;font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hr .m small{display:block;color:#9aa4d8;font-weight:600;font-size:11px;overflow:hidden;text-overflow:ellipsis}
.hr .rr{font-size:11px;font-weight:800;letter-spacing:.1em}
.medal{font-size:22px;min-width:30px;text-align:center}
#detail{position:fixed;inset:0;z-index:9;display:none;align-items:center;justify-content:center;background:#05060ce6;padding:16px}
#detail.on{display:flex}
.dc{width:min(86vw,290px);min-height:390px;border-radius:22px;padding:22px 16px;display:flex;flex-direction:column;align-items:center;justify-content:space-between;text-align:center;box-shadow:0 0 60px #000a;border:3px solid #ffffff80;animation:resin .5s ease-out both}
.dc .t{font-weight:900;letter-spacing:.06em;text-transform:uppercase;font-size:19px}
.dc .n{font-weight:900;font-size:88px;line-height:1}.dc .b{font-weight:900;letter-spacing:.3em;font-size:16px}
.dc .i{font-size:13px;font-weight:600;line-height:1.6}
.dbtn{margin-top:14px}
#vakTop{letter-spacing:.45em;font-size:clamp(13px,2.2vw,20px);font-weight:700;color:#b7c8ff;animation:vsub .7s .2s ease-out both}
#vakTop:empty{display:none}
#stage.res #cardWrap{opacity:.12;filter:blur(3px);transition:opacity .5s,filter .5s}
#impact{position:absolute;left:50%;bottom:4vh;transform:translateX(-50%);z-index:5;display:none;width:min(92vw,460px);text-align:center;background:#0a0c1ccc;border:1px solid var(--rc);border-radius:16px;padding:10px 16px;box-shadow:0 0 30px #0008;backdrop-filter:blur(6px)}
#impact.on{display:block;animation:vsub .6s ease-out both}
#impact b{display:block;letter-spacing:.3em;font-size:12px;color:var(--rc);margin-bottom:4px}
#impact span{display:block;font-size:14px;font-weight:700;line-height:1.55}
#rec{position:absolute;inset:0;z-index:6;display:none;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:16px;background:radial-gradient(circle,#2a1d00d0,#05060cf2);pointer-events:none}
#rec.on{display:flex;animation:fadein .4s ease-out both}
#rec .tr{font-size:clamp(54px,14vw,96px);animation:bump .6s ease-out;filter:drop-shadow(0 0 30px #ffd84a)}
#rec .rh{font-weight:900;letter-spacing:.14em;font-size:clamp(20px,5vw,40px);background:linear-gradient(90deg,#fff3a0,#ffd84a,#f3a81a);-webkit-background-clip:text;background-clip:text;color:transparent;animation:vzoom 1s cubic-bezier(.15,.9,.25,1) both}
#rec .rv{display:flex;gap:30px;align-items:flex-end;justify-content:center}
#rec .rv div{display:flex;flex-direction:column;align-items:center;font-size:11px;letter-spacing:.22em;color:#c9b27a;gap:4px}
#rec .rv b{font-size:clamp(34px,9vw,64px);font-weight:900;color:#fff;letter-spacing:0;line-height:1}
#rec .rv .nw b{color:#ffe27a;text-shadow:0 0 30px #ffd84a;animation:bump .6s .5s ease-out both}
#rec .ro{font-size:14px;font-weight:700;color:#ffe9a8;line-height:1.7}
#res{width:min(92vw,420px);max-height:92vh;overflow:auto;background:linear-gradient(170deg,#161a33f2,#0b0d1cf2);border:2px solid var(--rc);border-radius:22px;padding:20px 20px 18px;text-align:center;color:#fff;box-shadow:0 0 60px var(--rc),0 20px 60px #000c;animation:resin .6s cubic-bezier(.2,.9,.3,1) both}
.rt{letter-spacing:.4em;font-size:12px;font-weight:800;color:#aab4ee}
.rok{display:inline-block;margin:8px 0 0;padding:4px 12px;border-radius:99px;background:#1f8f4f33;color:#6dffa8;font-size:12px;font-weight:800;letter-spacing:.08em}
.rn{font-size:clamp(64px,18vw,96px);font-weight:900;line-height:1.05;margin-top:6px;text-shadow:0 0 28px var(--rc)}
.rb{letter-spacing:.3em;font-weight:900;font-size:15px;color:var(--rc);margin-bottom:10px}
#rL{display:flex;flex-direction:column;gap:6px;margin:8px 0}
.rl{background:#ffffff12;border-radius:10px;padding:7px 10px;font-size:13px;font-weight:700}
.rl.rc2{background:linear-gradient(90deg,#f3c13a33,#ffe27a22);color:#ffe27a}
#rS{display:grid;grid-template-columns:auto 1fr;gap:5px 14px;text-align:left;font-size:14px;margin:12px 0 14px;padding:10px 12px;background:#00000040;border-radius:12px}
#rS span{color:#9aa4d8}#rS b{text-align:right}
#res .btns{flex-direction:column}#res .btns button{width:100%}
@keyframes resin{from{opacity:0;transform:translateY(24px) scale(.94)}to{opacity:1;transform:none}}
@keyframes fadein{from{opacity:0}to{opacity:1}}
@media (prefers-reduced-motion:reduce){.shine,.front.pf,.it.op.new,.it.active .spk,.sp{animation:none!important}}

/* ===== filmische opening ===== */
#stage{position:fixed;inset:0;background:#03040a;display:none;overflow:hidden;color:#fff;text-align:center;--glow:#6aa8ff;--rc:#6aa8ff;--gmax:40px}
#stage.on{display:block;animation:sfade .7s ease-out}
@keyframes sfade{from{opacity:0}to{opacity:1}}
#fx{position:absolute;inset:0;width:100%;height:100%}
#tint{position:absolute;inset:0;mix-blend-mode:screen;background:radial-gradient(circle at 50% 50%,var(--tc,#000) 0,transparent 72%);opacity:0;transition:opacity 1s}
#rays{position:absolute;width:160vmax;height:160vmax;left:50%;top:50%;margin:-80vmax 0 0 -80vmax;background:repeating-conic-gradient(from 0deg,var(--glow) 0 5deg,transparent 5deg 15deg);opacity:0;transition:opacity .9s;animation:spin 16s linear infinite;-webkit-mask:radial-gradient(circle,#000 0,transparent 52%);mask:radial-gradient(circle,#000 0,transparent 52%)}
#stage.perfect #rays{animation:spin 16s linear infinite,hue 3s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}@keyframes hue{to{filter:hue-rotate(360deg)}}
#cam{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;will-change:transform}
#txt{position:absolute;left:0;right:0;top:50%;transform:translateY(-50%);display:none;flex-direction:column;align-items:center;gap:14px;padding:0 20px}
#txt.on{display:flex}
#vakWord{font-weight:900;text-transform:uppercase;line-height:1;color:#fff;text-shadow:0 0 40px #6aa8ffcc,0 0 90px #6aa8ff88;animation:vzoom 1.2s cubic-bezier(.15,.9,.25,1) both}
@keyframes vzoom{0%{transform:scale(.3);opacity:0;letter-spacing:.5em;filter:blur(10px)}35%{opacity:1;filter:blur(0)}100%{transform:scale(1.12);letter-spacing:.04em}}
#vakSub{letter-spacing:.5em;font-size:clamp(14px,2.4vw,22px);font-weight:700;color:#b7c8ff;animation:vsub .8s .5s ease-out both}
@keyframes vsub{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
#rarWord{position:absolute;left:0;right:0;top:9%;display:none;font-weight:900;font-size:clamp(46px,11vw,110px);line-height:1;color:var(--rc);text-shadow:0 0 50px var(--rc);animation:slam .55s cubic-bezier(.2,1.5,.4,1) both;z-index:3}
#rarWord.on{display:block}
#rarWord.rb,#bigNum{background:linear-gradient(90deg,#ff4d4d,#ffb84d,#f4ff4d,#4dff88,#4dc3ff,#9b4dff,#ff4dd2);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:none;filter:drop-shadow(0 0 28px #ff5fd2)}
@keyframes slam{0%{transform:scale(2.8);opacity:0}100%{transform:none;opacity:1}}
#cardWrap{display:none;perspective:1300px;transform:scale(var(--cs,1));margin-top:20px}
#cardWrap.in{display:block}
#cardBox{width:250px;height:360px}
#card3d{position:relative;width:100%;height:100%;transform-style:preserve-3d}
@keyframes cin{from{transform:scale(.05) translateZ(-700px);opacity:0}to{transform:none;opacity:1}}
@keyframes glowup{from{filter:drop-shadow(0 0 0 var(--rc))}to{filter:drop-shadow(0 0 var(--gmax) var(--rc))}}
@keyframes spinc{from{transform:rotateY(0)}to{transform:rotateY(720deg)}}
@keyframes flipin{from{transform:rotateY(-180deg)}to{transform:rotateY(0)}}
.face{position:absolute;inset:0;border-radius:22px;backface-visibility:hidden;-webkit-backface-visibility:hidden}
.back{background:linear-gradient(160deg,#1b1f45,#0a0b1c);border:3px solid var(--rc);box-shadow:inset 0 0 40px #000a;display:flex;align-items:center;justify-content:center}
.b2{transform:rotateY(180deg)}
.bk{display:flex;flex-direction:column;align-items:center;gap:12px}
.bk small{letter-spacing:.35em;font-size:11px;color:#9aa4d8}.bk b{letter-spacing:.4em;font-size:15px;color:#fff}
.front{display:none;flex-direction:column;align-items:center;justify-content:space-between;padding:22px 16px 20px;border:3px solid #ffffff80;overflow:hidden}
#card3d.sf .back{display:none}#card3d.sf .front{display:flex}
.shine{position:absolute;inset:0;background:linear-gradient(115deg,transparent 30%,#ffffff55 48%,transparent 62%);transform:translateX(-120%);animation:shn 3.2s 1s infinite;pointer-events:none}
@keyframes shn{to{transform:translateX(120%)}}
.ftop{font-weight:900;font-size:19px;letter-spacing:.06em;text-transform:uppercase;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.fnum{font-weight:900;font-size:112px;line-height:1;min-height:112px;text-shadow:0 4px 20px #0004}
.fnum.bump{animation:bump .35s ease-out}
@keyframes bump{0%{transform:scale(1.5)}100%{transform:none}}
.fbadge{font-weight:900;letter-spacing:.3em;font-size:18px;opacity:0;transition:opacity .5s}
.finfo{min-height:44px;font-size:14px;font-weight:600;opacity:0;transition:opacity .6s;line-height:1.4}
.fbadge.on,.finfo.on{opacity:1}
.front.pf{animation:hue 4s linear infinite}
#bigNum{position:absolute;left:0;right:0;top:50%;transform:translateY(-50%);font-weight:900;font-size:min(36vw,60vh);line-height:1;display:none;z-index:4;pointer-events:none}
#bigNum.on{display:block}
#bigNum.bump{animation:bump .4s ease-out}
#bigNum.out{animation:bout .7s ease-in forwards}
@keyframes bout{to{opacity:0;transform:translateY(-50%) scale(.3)}}
#after{position:absolute;inset:0;display:none;align-items:center;justify-content:center;padding:16px;z-index:5;background:radial-gradient(ellipse at center,#05060ccc,#05060cf2)}
#after.on{display:flex;animation:fadein .5s ease-out both}
.done{font-weight:800;font-size:18px}
.btns{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}
.btns button{border-radius:12px;padding:12px 20px;font-weight:800;font-size:15px;cursor:pointer;border:1px solid #3a3e66;background:#171a2b;color:#fff}
.btns button.pri{background:linear-gradient(180deg,#ffe27a,#e1a920);color:#2b2000;border:0;box-shadow:0 0 22px #f3c13a77}
#flash{position:absolute;inset:0;background:#fff;opacity:0;pointer-events:none;z-index:6}
#tools{position:absolute;top:14px;right:14px;display:flex;gap:6px;z-index:7}
#tools button{width:38px;height:38px;border-radius:10px;border:1px solid #ffffff22;background:#0008;color:#cfd3e6;cursor:pointer;font-size:16px}
#skip{position:absolute;right:16px;bottom:16px;z-index:7;background:#0008;color:#aab;border:1px solid #ffffff22;border-radius:10px;padding:8px 14px;cursor:pointer;font-size:13px}
@media (max-width:560px){.hero{flex-direction:column;gap:14px}.hd{grid-template-columns:1fr auto}.cnt{grid-column:1/3;grid-row:2}}
</style>
<button id="fab">🎴 Cijfer packs</button>
<div id="panel">
  <div class="modal">
    <div id="toast"></div>
    <div class="hd">
      <h2>🎁 Jouw cijfer packs</h2>
      <div class="cnt" id="cnt"></div>
      <div class="ic">
        <button class="ib" id="hSnd" title="Geluid"></button>
        <button class="ib" id="gear" title="Instellingen">⚙️</button>
        <button class="ib" id="x" title="Sluiten">✕</button>
      </div>
      <div id="menu">
        <button class="mi" id="mSnd"></button>
        <button class="mi" id="mShd"></button>
        <button class="mi" id="mMode"></button>
        <button class="mi" id="mStk"></button>
        <hr>
        <button class="mi dng" id="reset">↺ Opnieuw beginnen</button>
      </div>
    </div>
    <div class="tabs"><button class="tab on" id="tPacks">🎁 Packs</button><button class="tab" id="tSquad">⚽ Elftal</button><button class="tab" id="tStats">📊 Stats</button><button class="tab" id="tHist">🕘 Historie</button></div>
    <div id="packsView">
      <div class="bar" id="bar"><i></i></div>
      <div id="rstrip"></div>
      <div id="hero"></div>
      <div id="coll"></div>
    </div>
    <div id="squadView" style="display:none"></div>
    <div id="statsView" style="display:none"></div>
    <div id="histView" style="display:none"></div>
  </div>
  <div id="detail"></div>
</div>
<div id="stage">
  <canvas id="fx"></canvas>
  <div id="tint"></div>
  <div id="rays"></div>
  <div id="cam">
    <div id="txt"><div id="vakTop"></div><div id="vakWord"></div><div id="vakSub"></div></div>
    <div id="rarWord"></div>
    <div id="cardWrap"><div id="cardBox"><div id="card3d">
      <div class="face back"><div class="bk"><small>CIJFER PACK</small><svg viewBox="0 0 100 100" width="92"><circle cx="50" cy="50" r="42" fill="none" stroke="#fff" stroke-width="4"/><text x="50" y="62" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-style="italic" font-size="34" fill="#fff">CP</text></svg><b>MAGISTER</b></div></div>
      <div class="face back b2"><div class="bk"><small>CIJFER PACK</small><svg viewBox="0 0 100 100" width="92"><circle cx="50" cy="50" r="42" fill="none" stroke="#fff" stroke-width="4"/><text x="50" y="62" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-style="italic" font-size="34" fill="#fff">CP</text></svg><b>MAGISTER</b></div></div>
      <div class="face front" id="front"><div class="shine"></div><div class="ftop" id="fTop"></div><div class="fnum" id="fNum"></div><div class="fbadge" id="fBad"></div><div class="finfo" id="fInfo"></div></div>
    </div></div></div>
    <div id="bigNum"></div>
  </div>
  <div id="impact"></div>
  <div id="rec"></div>
  <div id="after">
    <div id="res">
      <div class="rt">PACK RESULT</div><div class="rok" id="rOk">✓ NIEUW CIJFER TOEGEVOEGD</div>
      <div class="rn" id="rN"></div><div class="rb" id="rB"></div>
      <div id="rL"></div>
      <div id="rS"></div>
      <div class="btns"><button id="bStats">📊 Bekijk statistieken</button><button id="bSee">📚 Collectie</button><button id="bNext" class="pri">Open volgende pack</button></div>
    </div>
  </div>
  <div id="flash"></div>
  <div id="tools"><button id="snd2"></button><button id="sx" title="Sluiten">✕</button></div>
  <button id="skip">Overslaan ›</button>
</div>`;
  root.addEventListener('pointerdown', () => ac(), true);
  const $ = id => root.getElementById(id);
  const stage = $('stage'), cv = $('fx'), cam = $('cam'), rays = $('rays'), tint = $('tint'), txt = $('txt'),
        vakWord = $('vakWord'), vakSub = $('vakSub'), rarWord = $('rarWord'), cardWrap = $('cardWrap'), cardBox = $('cardBox'),
        card3d = $('card3d'), front = $('front'), fNum = $('fNum'), fBad = $('fBad'), fInfo = $('fInfo'), fTop = $('fTop'),
        bigNum = $('bigNum'), after = $('after'), flashEl = $('flash'), skipBtn = $('skip');
  let items = [], armed = 0, newId = null;
  const impactEl = $('impact'), recEl = $('rec'), vakTop = $('vakTop');

  // ---------- canvas-effecten: tunnel, lichtlijnen, particles, confetti ----------
  const x = cv.getContext('2d');
  let W = 0, H = 0, dpr = 1;
  const size = () => { dpr = Math.min(1.5, window.devicePixelRatio || 1); W = cv.width = Math.round(innerWidth * dpr); H = cv.height = Math.round(innerHeight * dpr); };
  window.addEventListener('resize', () => { if (FX.on) size(); });
  const FX = { on: false, raf: 0, last: 0, tunnel: false, speed: 0, glowR: 0, glowCol: '#6aa8ff', hl: false, amb: false, stream: false, pal: PAL.gold,
    stars: [], rings: [], parts: [], conf: [], hls: [], tw: [], shakeAmp: 0, camS: 1, camT: 1 };
  const ease = k => k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
  const tween = (p, to, ms) => { FX.tw = FX.tw.filter(t => t.p !== p); FX.tw.push({ p, from: FX[p], to, t0: performance.now(), ms }); };
  const STARC = ['#6aa8ff', '#9b7bff', '#cfe3ff', '#ffffff'];
  function fxReset() {
    size();
    Object.assign(FX, { tunnel: false, speed: 0, glowR: 0, glowCol: '#6aa8ff', hl: false, amb: false, stream: false, parts: [], conf: [], hls: [], tw: [], shakeAmp: 0, camS: 1, camT: 1 });
    FX.stars = Array.from({ length: 170 }, () => ({ a: Math.random() * 6.283, d: Math.random(), c: STARC[(Math.random() * 4) | 0] }));
    FX.rings = Array.from({ length: 7 }, (_, i) => ({ z: i / 7, rot: Math.random() * 0.6, c: i % 2 ? '106,168,255' : '155,123,255' }));
    x.globalCompositeOperation = 'source-over'; x.fillStyle = '#03040a'; x.fillRect(0, 0, W, H);
  }
  const center = el => { const b = (el || cardBox).getBoundingClientRect(); return [(b.left + b.width / 2) * dpr, (b.top + b.height / 2) * dpr]; };
  function burst(n, sp, sz, life, at) {
    if (RM.matches) n = Math.ceil(n * .3);
    const p = at || [W / 2, H / 2];
    for (let i = 0; i < n && FX.parts.length < 1400; i++) {
      const a = Math.random() * 6.283, v = sp * (0.25 + Math.random()) * dpr;
      FX.parts.push({ x: p[0], y: p[1], vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 0.05 * dpr, t: 0, l: life * (0.6 + Math.random() * 0.8), c: FX.pal[(Math.random() * FX.pal.length) | 0], s: sz * (0.5 + Math.random()) * dpr });
    }
  }
  function confetti(n) {
    if (RM.matches) n = Math.round(n * .25);
    for (let i = 0; i < n && FX.conf.length < 500; i++) {
      FX.conf.push({ x: Math.random() * W, y: -20 * dpr - Math.random() * H * 0.6, vx: (Math.random() - .5) * 4 * dpr, vy: (2 + Math.random() * 4) * dpr, r: Math.random() * 6, vr: (Math.random() - .5) * .3,
        w: (6 + Math.random() * 8) * dpr, h: (4 + Math.random() * 6) * dpr, c: PAL.perfect[(Math.random() * 8) | 0] });
    }
  }
  function frame(now) {
    if (!FX.on) return;
    FX.raf = requestAnimationFrame(frame);
    const dt = Math.min(2.5, (now - FX.last) / 16.67 || 1); FX.last = now;
    // tweens
    FX.tw = FX.tw.filter(t => { const k = Math.min(1, (now - t.t0) / t.ms); FX[t.p] = t.from + (t.to - t.from) * ease(k); return k < 1; });
    const cx = W / 2, cy = H / 2, R = Math.hypot(W, H) / 2;
    x.globalCompositeOperation = 'source-over';
    x.fillStyle = FX.tunnel ? 'rgba(3,4,10,.24)' : 'rgba(3,4,10,.33)'; x.fillRect(0, 0, W, H);
    x.globalCompositeOperation = 'lighter';
    if (FX.glowR > 0) {
      const g = x.createRadialGradient(cx, cy, 0, cx, cy, R * FX.glowR);
      g.addColorStop(0, rgba(FX.glowCol, .55)); g.addColorStop(1, rgba(FX.glowCol, 0)); x.fillStyle = g; x.fillRect(0, 0, W, H);
    }
    if (FX.tunnel) {
      FX.rings.forEach(r => {
        r.z += 0.005 * FX.speed * dt * (1 + r.z * 2.2); if (r.z > 1.15) r.z = 0.03;
        const rad = r.z * R * 0.9; x.save(); x.translate(cx, cy); x.rotate(r.rot + r.z * 0.4);
        x.strokeStyle = `rgba(${r.c},${Math.min(.5, r.z * .8) * Math.min(1, FX.speed + .2)})`; x.lineWidth = (1 + r.z * 5) * dpr; x.strokeRect(-rad, -rad, rad * 2, rad * 2); x.restore();
      });
      FX.stars.forEach(s => {
        s.d += (0.004 + s.d * 0.045) * FX.speed * dt;
        if (s.d > 1.15) { s.d = 0.01 + Math.random() * 0.05; s.a = Math.random() * 6.283; }
        const ca = Math.cos(s.a), sa = Math.sin(s.a), r1 = s.d * R, r0 = Math.max(0, (s.d - (0.008 + s.d * 0.14 * FX.speed)) * R);
        x.globalAlpha = Math.min(1, s.d * 2.4); x.strokeStyle = s.c; x.lineWidth = (0.6 + s.d * 2.4) * dpr;
        x.beginPath(); x.moveTo(cx + ca * r0, cy + sa * r0); x.lineTo(cx + ca * r1, cy + sa * r1); x.stroke();
      });
      x.globalAlpha = 1;
      if (Math.random() < .5) FX.parts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .3 * dpr, vy: (Math.random() - .5) * .3 * dpr, g: 0, t: 0, l: 90, c: '#cfe3ff', s: (0.6 + Math.random() * 1.2) * dpr });
    }
    if (FX.hl) {
      for (let i = 0; i < 3; i++) { const left = Math.random() < .5; FX.hls.push({ y: Math.random() * H, x: left ? -300 * dpr : W + 300 * dpr, vx: (left ? 1 : -1) * (30 + Math.random() * 50) * dpr, len: (120 + Math.random() * 360) * dpr, w: (1 + Math.random() * 2.5) * dpr, a: .25 + Math.random() * .5, c: Math.random() < .7 ? '106,168,255' : '255,255,255' }); }
    }
    FX.hls = FX.hls.filter(l => {
      l.x += l.vx * dt; const g = x.createLinearGradient(l.x - Math.sign(l.vx) * l.len, 0, l.x, 0);
      g.addColorStop(0, `rgba(${l.c},0)`); g.addColorStop(1, `rgba(${l.c},${l.a})`); x.strokeStyle = g; x.lineWidth = l.w;
      x.beginPath(); x.moveTo(l.x - Math.sign(l.vx) * l.len, l.y); x.lineTo(l.x, l.y); x.stroke();
      return l.x > -600 * dpr && l.x < W + 600 * dpr;
    });
    if (FX.stream) for (let i = 0; i < 5; i++) FX.parts.push({ x: -10, y: Math.random() * H, vx: (14 + Math.random() * 16) * dpr, vy: (Math.random() - .5) * 3 * dpr, g: 0, t: 0, l: 70, c: FX.pal[(Math.random() * FX.pal.length) | 0], s: (1.5 + Math.random() * 3) * dpr });
    if (FX.amb && Math.random() < .35) { const a = Math.random() * 6.283, rr = (150 + Math.random() * 200) * dpr; FX.parts.push({ x: cx + Math.cos(a) * rr, y: cy + Math.sin(a) * rr, vx: (Math.random() - .5) * .8 * dpr, vy: -(0.4 + Math.random() * .8) * dpr, g: 0, t: 0, l: 110, c: FX.pal[(Math.random() * FX.pal.length) | 0], s: (1 + Math.random() * 2.5) * dpr }); }
    FX.parts = FX.parts.filter(p => {
      p.t += dt; p.vx *= .985; p.vy = p.vy * .985 + p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt;
      const k = p.t / p.l; if (k >= 1) return false;
      x.globalAlpha = 1 - k; x.fillStyle = p.c; x.beginPath(); x.arc(p.x, p.y, p.s, 0, 6.283); x.fill(); return true;
    });
    x.globalAlpha = 1; x.globalCompositeOperation = 'source-over';
    FX.conf = FX.conf.filter(c => {
      c.vy += .06 * dpr * dt; c.vx *= .995; c.x += c.vx * dt; c.y += c.vy * dt; c.r += c.vr * dt;
      x.save(); x.translate(c.x, c.y); x.rotate(c.r); x.scale(1, Math.abs(Math.cos(c.r * 1.7)) + .15); x.fillStyle = c.c; x.fillRect(-c.w / 2, -c.h / 2, c.w, c.h); x.restore();
      return c.y < H + 30 * dpr;
    });
    // camera: langzame zoom + shake
    FX.camS += (FX.camT - FX.camS) * 0.006 * dt; FX.shakeAmp *= Math.pow(.93, dt);
    const sx = (Math.random() - .5) * FX.shakeAmp * 2, sy = (Math.random() - .5) * FX.shakeAmp * 2;
    cam.style.transform = `translate(${sx.toFixed(1)}px,${sy.toFixed(1)}px) scale(${FX.camS.toFixed(4)})`;
  }
  const fxStart = () => { FX.on = true; FX.last = performance.now(); cancelAnimationFrame(FX.raf); FX.raf = requestAnimationFrame(frame); };
  const fxStop = () => { FX.on = false; cancelAnimationFrame(FX.raf); };
  const flash = (a, ms) => { if (RM.matches) a = Math.min(a, .12); flashEl.style.transition = 'none'; flashEl.style.opacity = a; void flashEl.offsetWidth; flashEl.style.transition = `opacity ${ms || 700}ms ease-out`; flashEl.style.opacity = 0; };
  const setRays = (col, op) => { stage.style.setProperty('--glow', col); rays.style.opacity = op; };
  const setTint = (col, a) => { tint.style.setProperty('--tc', col); tint.style.opacity = a; };
  const bump = el => { el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); };

  // ---------- de timeline ----------
  let tok = 0, cur = null, curR = null, finalShown = false;
  const sleep = (ms, my) => new Promise(r => setTimeout(() => r(my === tok), ms));
  const labels = () => {
    $('hSnd').textContent = muted ? '🔇' : '🔊'; $('snd2').textContent = muted ? '🔇' : '🔊';
    $('mSnd').textContent = '🔊 Geluid: ' + (muted ? 'uit' : 'aan'); $('mShd').textContent = '🙈 Cijfers verbergen: ' + (shieldOn ? 'aan' : 'uit');
    $('mMode').textContent = 'Opening: ' + MODES[mode] + (RM.matches && mode === 'cin' ? ' (rustig)' : ''); $('mStk').textContent = '🔥 Reeks-grens: ' + fmt(streakMin) + '+';
  };

  function prepStage(g, r, T) {
    stage.className = 'on' + (r[0] === 'perfect' ? ' perfect' : '');
    stage.style.setProperty('--rc', r[2]); stage.style.setProperty('--gmax', T.gmax + 'px');
    setRays('#6aa8ff', 0); setTint('#000', 0);
    txt.className = ''; rarWord.className = ''; rarWord.textContent = ''; after.className = ''; impactEl.className = ''; recEl.className = ''; skipBtn.textContent = 'Overslaan ›'; bigNum.className = ''; bigNum.textContent = '';
    cardWrap.className = ''; cardBox.style.animation = 'none'; card3d.style.animation = 'none'; card3d.className = '';
    front.className = 'face front' + (r[0] === 'perfect' ? ' pf' : ''); front.style.background = r[3]; front.style.color = r[4];
    fNum.textContent = ''; fNum.style.fontSize = fmt(g.c).length > 3 ? '84px' : ''; fBad.className = 'fbadge'; fBad.textContent = r[0] === 'perfect' ? '★ PERFECT CIJFER ★' : r[1]; fBad.style.fontSize = r[0] === 'perfect' ? '12px' : ''; fInfo.className = 'finfo';
    fTop.textContent = emo(g.vak) + ' ' + g.vak;
    fInfo.innerHTML = [g.oms ? esc(g.oms) : '', g.weging ? 'Gewicht: ' + esc(g.weging) : '', g.d ? fmtDate(g.d) : ''].filter(Boolean).join('<br>');
    skipBtn.style.display = 'block'; finalShown = false;
    cardWrap.style.setProperty('--cs', Math.max(.45, Math.min(1, (innerHeight - 250) / 370, (innerWidth - 40) / 260)).toFixed(3));
    FX.pal = PAL[r[0]]; fxReset(); fxStart();
  }

  const tcFor = (key, ts) => {
    const T = Object.assign({}, TC[key]);
    if (ts < 1) ['tun', 'vak', 'card', 'rar', 'dig', 'bo'].forEach(k => { T[k] = Math.round(T[k] * ts); });
    if (RM.matches) { T.n = Math.round(T.n * .3); T.shake = 0; delete T.zoom; T.fl = Math.min(T.fl, .35); T.gmax = Math.round(T.gmax * .5); }
    return T;
  };

  // momentopname vóór het openen: alle 'voor'-statistieken komen uit dezelfde centrale laag
  function beginPull(g) {
    const others = openedList().filter(o => o.id !== g.id);
    PULL = { id: g.id, isNew: !opened.has(g.id), others, before: computeStats(others, streakMin) };
  }
  // slaat het cijfer op en rekent alles opnieuw uit (gemiddelde, records, rarity, reeksen, percentiel)
  function commitPull(g) {
    const isNew = !!(PULL && PULL.id === g.id && PULL.isNew);
    cards[g.id] = Object.assign({}, cards[g.id], { vak: g.vak, c: g.c, oms: g.oms, weging: g.weging, d: g.d });
    if (isNew) cards[g.id].t = Date.now();
    opened.add(g.id); store.saveOpened(); store.saveCards(); shield();
    if (!isNew) return { isNew: false, after: computeStats(openedList(), streakMin) };
    const now = Object.assign({ id: g.id }, cards[g.id]), before = PULL.before, others = PULL.others;
    const after = computeStats(others.concat([now]), streakMin), P = { isNew: true, before, after, recs: [], ms: '' };
    if (others.length >= 3) P.pct = Math.round(others.filter(x => x.c < g.c).length / others.length * 100);
    if (before.n) { P.d = after.avg - before.avg; if (g.weging && before.w && after.w) P.dw = after.w.v - before.w.v; }
    const prev = rec || { best: before.n ? before.max.c : null, avg: before.n >= 3 ? before.avg : null, streak: before.streak || 0 };
    if (before.n >= 3) {
      if (prev.best != null && g.c > prev.best) P.recs.push({ hero: 1, icon: '🏆', t: 'NIEUW PERSOONLIJK RECORD', prev: fmt(prev.best), now: fmt(g.c) });
      if (prev.avg != null && after.avg > prev.avg + .004) P.recs.push({ icon: '📈', t: 'Hoogste gemiddelde ooit', prev: f2(prev.avg), now: f2(after.avg) });
      if (prev.streak >= 1 && after.streak > prev.streak) P.recs.push({ icon: '🔥', t: 'Langste goede reeks', prev: prev.streak, now: after.streak });
    }
    P.ms = g.c >= 10 ? '🌈 Perfecte cijfers: ' + after.n10 : g.c >= 9 ? '🔥 Cijfers van 9+: ' + after.n9 : g.c >= 8 ? '💎 Cijfers van 8+: ' + after.n8 : '';
    rec = { best: Math.max(prev.best || 0, g.c), avg: after.n >= 3 ? Math.max(prev.avg || 0, after.avg) : prev.avg, streak: Math.max(prev.streak || 0, after.streak) };
    store.saveRec();
    return P;
  }

  async function startPack(g) {
    const my = ++tok, r = rar(g.c), key = r[0], L = LV[key], em = effMode(), ts = em === 'quick' ? .45 : 1, S = n => Math.round(n * ts), T = tcFor(key, ts);
    cur = g; curR = r; ac(); killSound(); beginPull(g);
    prepStage(g, r, T);
    if (em === 'inst') { skipAnim(true); return; }
    const wt = ms => sleep(ms, my);
    const idx = items.indexOf(g) + 1;

    // 🌑 blackout
    snd.blackout(L); FX.glowCol = '#6aa8ff'; tween('glowR', 0.1, T.bo + S(500));
    if (!await wt(T.bo + S(500))) return;

    // ✨ tunnel
    FX.tunnel = true; FX.speed = .15; tween('speed', 1, T.tun); tween('glowR', .32, T.tun); if (T.zoom) FX.camT = T.zoom;
    snd.tunnel(T.tun, L); setRays('#6aa8ff', .12);
    if (!await wt(T.tun)) return;

    // 📚 vak
    flash(.3, 500); FX.shakeAmp = T.shake; FX.hl = true; setRays('#3d7bff', T.ray); setTint(r[2], T.tint); snd.vak(L);
    vakWord.textContent = g.vak; vakWord.style.fontSize = `min(${Math.max(34, Math.min(120, 1100 / g.vak.length))}px,13vw)`;
    vakWord.style.animation = 'none'; vakSub.style.animation = 'none'; void vakWord.offsetWidth; vakWord.style.animation = ''; vakSub.style.animation = '';
    vakTop.textContent = g.weging ? 'GEWICHT: ' + g.weging : ''; vakTop.style.animation = 'none'; void vakTop.offsetWidth; vakTop.style.animation = '';
    vakSub.textContent = 'CIJFER ' + idx; txt.className = 'on';
    burst(T.n / 3, 9, 2, 60);
    if (!await wt(T.vak)) return;
    txt.className = ''; FX.hl = false; setTint('#000', 0);

    // 🎴 kaart
    if (T.dark) { FX.tunnel = false; FX.speed = 0; tween('glowR', 0, 400); setRays('#000', 0); snd.tension(T.card + S(700), L); if (!await wt(S(700))) return; }
    else { tween('speed', .25, 600); setRays(r[2], T.ray * .6); }
    const cin = T.dark ? S(1800) : Math.round(T.card * .4);
    cardWrap.className = 'in';
    cardBox.style.animation = `cin ${cin}ms cubic-bezier(.2,.8,.2,1) both, glowup ${T.card}ms ease-in forwards`;
    card3d.style.animation = `spinc ${T.card}ms cubic-bezier(.45,0,.25,1) both`;
    snd.cardIn(cin, L); snd.spin(T.card, L);
    if (!await wt(T.card)) return;
    card3d.style.animation = 'none';

    // ⚡ rarity
    FX.tunnel = false; flash(T.fl, key === 'perfect' ? 1400 : 900); FX.shakeAmp = T.shake * 1.4; snd.flash(L);
    setRays(r[2], T.ray); setTint(r[2], T.tint); FX.glowCol = r[2]; tween('glowR', .45, 600);
    if (T.rar) {
      rarWord.textContent = key === 'perfect' ? 'PERFECT' : r[1]; rarWord.className = 'on' + (key === 'perfect' ? ' rb' : '');
      rarWord.style.animation = 'none'; void rarWord.offsetWidth; rarWord.style.animation = '';
      FX.stream = !!T.stream; burst(T.n / 2, 12, 3, 80, center()); snd.cat(key);
      if (key === 'perfect') { snd.perfect(); confetti(60); }
      if (!await wt(T.rar)) return;
    }
    FX.stream = false; rarWord.className = '';

    // 💥 cijfer
    card3d.classList.add('sf'); card3d.style.animation = 'flipin 700ms cubic-bezier(.2,.9,.3,1) both'; snd.whoosh();
    const s = fmt(g.c), perfect = key === 'perfect';
    if (!await wt(S(450))) return;
    for (let i = 1; i <= s.length; i++) {
      const part = s.slice(0, i);
      if (perfect) { bigNum.textContent = part; bigNum.className = 'on'; bump(bigNum); }
      else { fNum.textContent = part; bump(fNum); }
      snd.digit(i, L); FX.shakeAmp = Math.max(FX.shakeAmp, T.shake * .6);
      burst(Math.round(T.n / 5) + (i === s.length ? T.n : 0), i === s.length ? 14 : 8, 3, 70, perfect ? [W / 2, H / 2] : center());
      if (!await wt(T.dig)) return;
    }
    snd.final(key); FX.shakeAmp = T.shake * 1.3; flash(.25 + L * .08, 600); FX.amb = true;
    if (perfect) { confetti(220); if (!await wt(S(1300))) return; bigNum.className = 'on out'; fNum.textContent = s; bump(fNum); await wt(S(500)); bigNum.className = ''; if (my !== tok) return; }
    else if (L >= 4) confetti(40);
    fBad.classList.add('on'); if (!await wt(S(450))) return;
    fInfo.classList.add('on'); if (!await wt(S(500))) return;
    showAfter();
  }

  let skipWake = null, afterFast = false;
  async function showAfter(how) {
    const g = cur, r = curR, my = tok;
    finalShown = true; afterFast = false; FX.amb = true; FX.stream = false; FX.hl = false;
    const P = commitPull(g);
    const quick = how === 'skip' || effMode() === 'quick', inst = how === 'inst', ts = inst ? 0 : quick ? .5 : 1;
    const w = ms => new Promise(res => {
      if (afterFast || ms <= 0) return res(my === tok);
      const id = setTimeout(() => { skipWake = null; res(my === tok); }, ms);
      skipWake = () => { clearTimeout(id); skipWake = null; res(my === tok); };
    });
    skipBtn.textContent = 'Verder ›'; skipBtn.style.display = ts ? 'block' : 'none';
    if (!await w(inst ? 650 : 500)) return;

    // 💥 impact (pas NA de cijferonthulling)
    if (P.isNew && ts) {
      const L = [`Cijfer: ${fmt(g.c)}` + (g.weging ? ` · Gewicht: ${esc(g.weging)}` : '')];
      if (P.d != null) { L.push(`Effect op gemiddelde: ${fd(P.d)}`); L.push(`Je gemiddelde: ${f2(P.before.avg)} → ${f2(P.after.avg)}`); }
      if (P.dw != null) L.push(`Gewogen gemiddelde: ${f2(P.before.w.v)} → ${f2(P.after.w.v)} (${fd(P.dw)})`);
      if (P.pct != null) L.push(P.pct > 0 ? `Beter dan ${P.pct}% van je eigen cijfers` : '💀 Je laagste cijfer tot nu toe');
      const head = P.d == null ? 'EERSTE KAART' : Math.abs(P.d) >= .3 ? 'GROTE IMPACT' : Math.abs(P.d) >= .1 ? 'IMPACT' : 'KLEINE IMPACT';
      impactEl.innerHTML = `<b>${head}</b><span>${L.join('<br>')}</span>`; impactEl.className = 'on'; snd.ping();
      if (!await w(2600 * ts)) return;
      impactEl.className = '';
    }

    // 🏆 persoonlijk record
    if (P.isNew && P.recs.length && ts) {
      const main = P.recs.find(x => x.hero) || P.recs[0], extra = P.recs.filter(x => x !== main);
      recEl.innerHTML = `<div class="tr">${main.icon}</div><div class="rh">${main.t.toUpperCase()}</div>` +
        `<div class="rv"><div>VORIGE<b>${main.prev}</b></div><div class="nw">NIEUW<b>${main.now}</b></div></div>` +
        extra.map(x => `<div class="ro">${x.icon} ${x.t}: ${x.prev} → ${x.now}</div>`).join('');
      recEl.className = 'on'; setTint('#f3c13a', .35); FX.glowCol = '#ffd84a'; tween('glowR', .55, 500);
      burst(main.hero ? 240 : 120, 16, 3, 90, [W / 2, H / 2]); confetti(main.hero ? 100 : 45); flash(.35, 700); snd.record();
      if (!await w(3400 * ts)) return;
      recEl.className = ''; setTint(r[2], TC[r[0]].tint);
    }

    // 📋 resultaatkaart
    const A = P.after, total = Math.max(items.length, Object.keys(cards).length);
    $('rOk').style.display = P.isNew ? '' : 'none';
    $('rN').textContent = fmt(g.c); $('rB').textContent = r[0] === 'perfect' ? '★ PERFECT CIJFER ★' : r[1];
    const lines = [];
    P.recs && P.recs.forEach(x => lines.push(`<div class="rl rc2">${x.icon} ${x.hero ? 'Nieuw persoonlijk record' : x.t}: ${x.prev} → ${x.now}</div>`));
    if (P.ms) lines.push(`<div class="rl">${P.ms}</div>`);
    if (P.pct != null && P.pct > 0) lines.push(`<div class="rl">Beter dan ${P.pct}% van je eigen cijfers</div>`);
    $('rL').innerHTML = lines.join('');
    $('rS').innerHTML = `<span>Gemiddelde</span><b>${P.isNew && P.before.n ? f2(P.before.avg) + ' → ' + f2(A.avg) : f2(A.avg)}</b>` +
      (A.w ? `<span>Gewogen gemiddelde</span><b>${f2(A.w.v)}</b>` : '') +
      `<span>Hoogste ooit</span><b>${fmt(A.max.c)}</b><span>Geopend</span><b>${A.n} / ${total}</b>`;
    const nx = items.findIndex(i => !opened.has(i.id));
    $('bNext').style.display = nx >= 0 ? '' : 'none';
    skipBtn.style.display = 'none'; impactEl.className = ''; recEl.className = '';
    stage.classList.add('res'); after.className = 'on';
  }

  function skipAnim(inst) {
    if (!cur || finalShown) return;
    tok++; killSound(); const g = cur, r = curR, T = tcFor(r[0], 1);
    FX.tunnel = false; FX.hl = false; FX.stream = false; FX.glowR = .4; FX.glowCol = r[2];
    txt.className = ''; rarWord.className = ''; bigNum.className = ''; cardWrap.className = 'in';
    cardBox.style.animation = `glowup 400ms ease-out forwards`; card3d.style.animation = 'none'; card3d.classList.add('sf');
    fNum.textContent = fmt(g.c); fBad.classList.add('on'); fInfo.classList.add('on');
    setRays(r[2], T.ray); setTint(r[2], T.tint); flash(.4, 500); burst(T.n / 2, 10, 3, 70, center());
    if (inst) snd.final(r[0]);
    showAfter(inst ? 'inst' : 'skip');
  }

  function closeStage(toCollection, goTab) {
    tok++; killSound(); fxStop(); skipWake = null; stage.className = ''; cardWrap.className = ''; after.className = ''; impactEl.className = ''; recEl.className = '';
    const g = cur; cur = null;
    if (toCollection && g) {
      newId = g.id; tab = goTab || 'packs'; pickSlot = null; openPanel();
      if (PULL && PULL.id === g.id && PULL.isNew) {
        const total = items.length, done = items.filter(i => opened.has(i.id)).length;
        const t = $('toast'); t.textContent = `✓ NIEUW CIJFER TOEGEVOEGD · ${done} / ${total} cijfers verzameld`; t.className = 'on'; setTimeout(() => { t.className = ''; }, 3600);
      }
    } else refresh();
  }

  // ---------- paneel (overzicht) ----------
  function refresh() {
    items = scan(); syncCards(items);
    const total = items.length, done = items.filter(i => opened.has(i.id)).length, nx = items.findIndex(i => !opened.has(i.id));
    $('cnt').textContent = total ? `${done} / ${total} cijfers verzameld` : '';
    const O = computeStats(openedList(), streakMin);
    $('rstrip').innerHTML = O.n ? R.map((x, i) => `<span class="rc" style="border-color:${x[2]};color:${x[2]}">${x[1]} <b>${O.rar[i]}</b></span>`).join('') + `<span class="rc best">🏆 Beste ${fmt(O.max.c)}</span>` : '';
    $('bar').style.display = total ? 'block' : 'none';
    $('bar').firstElementChild.style.width = (total ? done / total * 100 : 0) + '%';
    if (!total) {
      $('hero').innerHTML = '<div class="empty">Geen cijfers gevonden.<br>Ga eerst naar de pagina met je cijfers in Magister en klik dan opnieuw.</div>'; $('coll').innerHTML = '';
    } else {
      $('hero').innerHTML = nx >= 0 ? `
        <div class="hero">
          <div class="pw" data-i="${nx}">${PK}<span class="sp s1">✨</span><span class="sp s2">✨</span><span class="sp s3">✨</span><span class="sp s4">✨</span></div>
          <div class="info"><small>🎁 Volgende cijfer</small><h3>Pack ${nx + 1}</h3><div class="q">???</div>
            <button class="big" data-i="${nx}">OPEN PACK ✨</button><div class="left">${total - done} nog te openen</div></div>
        </div>` : `<div class="hero done"><b>🎉 Alles geopend!</b><span>Je hebt al je ${total} packs geopend.</span></div>`;
      $('coll').innerHTML = `<div class="ct">📚 Jouw collectie · ${done} / ${total} cijfers</div><div class="grid">` + items.map((g, i) => {
        if (opened.has(g.id)) {
          const r = rar(g.c);
          return `<div class="it op${g.id === newId ? ' new' : ''}" data-i="${i}" data-new="${g.id === newId ? 1 : ''}" title="Opnieuw bekijken" style="background:${r[3]};color:${r[4]}">
            <div class="vk">${esc(g.vak)}</div><div class="gn">${fmt(g.c)}</div><div class="badge">${r[1]}</div><div class="ck">✓ GEOPEND</div></div>`;
        }
        return `<div class="it cl${i === nx ? ' active' : ''}" data-i="${i}">${i === nx ? '<span class="spk">✨</span>' : ''}${PK}<div class="lb">Pack ${i + 1}</div><button class="sm"><span>Open pack</span><span class="ar"> →</span></button></div>`;
      }).join('') + '</div>';
    }
    shield(); applyTab();
    if (newId) { const n = $('coll').querySelector('[data-new="1"]'); if (n) setTimeout(() => n.scrollIntoView({ block: 'center', behavior: 'smooth' }), 100); newId = null; }
  }

  // ---------- elftal ----------
  const FORM = {
    '4-3-3': { lines: [3, 3, 4, 1], pos: [[18, 14], [50, 9], [82, 14], [25, 40], [50, 36], [75, 40], [12, 66], [37, 68], [63, 68], [88, 66], [50, 90]] },
    '4-4-2': { lines: [2, 4, 4, 1], pos: [[35, 12], [65, 12], [13, 38], [38, 40], [62, 40], [87, 38], [12, 66], [37, 68], [63, 68], [88, 66], [50, 90]] },
    '3-5-2': { lines: [2, 5, 3, 1], pos: [[35, 12], [65, 12], [10, 40], [30, 44], [50, 34], [70, 44], [90, 40], [22, 68], [50, 70], [78, 68], [50, 90]] },
    '4-5-1': { lines: [1, 5, 4, 1], pos: [[50, 10], [10, 38], [30, 42], [50, 34], [70, 42], [90, 38], [12, 66], [37, 68], [63, 68], [88, 66], [50, 90]] }
  };
  const LINE_L = ['Aanval', 'Middenveld', 'Verdediging', 'Keeper'];
  const slotLine = i => { let a = 0; for (let k = 0; k < 4; k++) { a += FORM[squad.f].lines[k]; if (i < a) return LINE_L[k]; } return ''; };
  const cardList = () => Object.keys(cards).filter(id => opened.has(id)).map(id => Object.assign({ id }, cards[id])).sort((a, b) => b.c - a.c);

  function renderSquad() {
    const v = $('squadView'), all = cardList();
    if (!all.length) {
      v.innerHTML = '<div class="empty">' + (opened.size
        ? 'Je geopende cijfers worden ingelezen.<br>Open dit venster één keer op de pagina met je cijfers, dan verschijnen ze hier.'
        : 'Je hebt nog geen geopende packs.<br>Open eerst een paar packs, dan kun je hier je elftal samenstellen.') + '</div>';
      return;
    }
    if (pickSlot !== null) {
      const cur = squad.s[pickSlot];
      v.innerHTML = `<div class="ct">Kies een kaart · ${slotLine(pickSlot)}</div><div class="grid">` + all.map(g => {
        const r = rar(g.c), used = squad.s.includes(g.id);
        return `<div class="it op${g.id === cur ? ' sel' : ''}" data-pick="${g.id}" style="background:${r[3]};color:${r[4]}"><div class="vk">${esc(g.vak)}</div><div class="gn">${fmt(g.c)}</div><div class="badge">${r[1]}</div><div class="ck">${g.id === cur ? '✓ HIER' : used ? 'IN ELFTAL' : '&nbsp;'}</div></div>`;
      }).join('') + `</div><div class="btns sqb"><button data-act="cancel">‹ Terug</button>${cur ? '<button data-act="remove">Verwijder uit elftal</button>' : ''}</div>`;
      return;
    }
    const F = FORM[squad.f];
    const slots = squad.s.map(id => (id && cards[id] && opened.has(id)) ? cards[id] : null);
    const got = slots.filter(Boolean), avg = got.length ? got.reduce((a, g) => a + g.c, 0) / got.length : 0;
    const best = all.slice(0, 11), bavg = best.reduce((a, g) => a + g.c, 0) / best.length;
    const r = rar(got.length ? avg : 1);
    const perfect = got.length === Math.min(11, all.length) && Math.abs(avg - bavg) < 0.005;
    v.innerHTML = `
      <div class="sqtop">
        <div class="avg" style="background:${r[3]};color:${r[4]}"><small>ELFTAL GEMIDDELDE</small><b>${got.length ? f2(avg) : '–'}</b><span>${got.length} / 11 spelers · ${r[1]}</span></div>
        <div class="sqctl">
          <select id="fsel">${Object.keys(FORM).map(k => `<option${k === squad.f ? ' selected' : ''}>${k}</option>`).join('')}</select>
          <button class="pri" data-act="auto">⚡ Beste elftal</button>
          <button data-act="clear">Leegmaken</button>
        </div>
      </div>
      <div class="pitch"><i class="bx t"></i><i class="bx b"></i>` + F.pos.map((p, i) => {
        const g = slots[i];
        if (!g) return `<div class="slot em" data-slot="${i}" style="left:${p[0]}%;top:${p[1]}%" title="${slotLine(i)}"><b>+</b></div>`;
        const rr = rar(g.c);
        return `<div class="slot" data-slot="${i}" style="left:${p[0]}%;top:${p[1]}%;background:${rr[3]};color:${rr[4]}" title="${esc(g.vak)}"><b>${fmt(g.c)}</b><span>${esc(g.vak)}</span></div>`;
      }).join('') + `</div>
      <div class="sqhint">${perfect ? '🏆 Dit is je best mogelijke elftal!' : (all.length >= 11 ? 'Beste mogelijke elftal: ' + f2(bavg) : 'Open meer packs voor een vol elftal')} · klik op een plek om een kaart te kiezen</div>`;
  }
  // ---------- statistiekenpagina ----------
  const hrow = (g, md) => {
    const r = rar(g.c);
    return `<div class="hr" data-det="${g.id}">${md ? '<div class="medal">' + md + '</div>' : ''}<div class="g" style="background:${r[3]};color:${r[4]}">${fmt(g.c)}</div><div class="m">${esc(g.vak)}<small>${esc(g.oms || '')}${g.t ? ' · geopend ' + new Date(g.t).toLocaleDateString('nl-NL') : ''}</small></div><div class="rr" style="color:${r[2]}">${r[1]}</div></div>`;
  };
  const bar = (nm, pct, val, col) => `<div class="br"><div class="nm">${nm}</div><div class="trk"><i style="width:${Math.max(2, Math.min(100, pct))}%${col ? ';background:' + col : ''}"></i></div><div class="vl">${val}</div></div>`;
  const sc = (label, val, sub, big, na) => `<div class="sc${big ? ' big' : ''}${na ? ' na' : ''}"><small>${label}</small><b>${val}</b>${sub ? '<span>' + sub + '</span>' : ''}</div>`;
  const NA = 'Niet genoeg gegevens';
  function renderStats() {
    const v = $('statsView'), a = basisList(), S = computeStats(a, streakMin), op = openedList(), known = Object.keys(cards).length, pending = opened.size - op.length;
    let h = `<div class="sbasis"><span class="snote" style="margin:0">Basis:</span><button data-basis="o" class="${statsAll ? '' : 'on'}">🔒 Geopende cijfers</button><button data-basis="a" class="${statsAll ? 'on' : ''}">👁 Alle cijfers</button></div>`;
    h += statsAll ? `<div class="snote warn">⚠ Gebaseerd op alle ${S.n} bekende cijfers, ook die van packs die nog dicht zijn. Dit kan spoilers geven.</div>`
      : `<div class="snote">Gebaseerd op ${S.n} van ${known} bekende cijfers: alleen onthulde cijfers, dus geen spoilers.${pending > 0 ? ' ' + pending + ' geopende pack(s) worden ingelezen zodra je op je cijferpagina bent.' : ''}</div>`;
    if (!S.n) { v.innerHTML = h + `<div class="empty">${NA}.<br>Open een pack of ga naar je cijferpagina om cijfers in te lezen.</div>`; return; }
    const bestPull = op.length ? op.reduce((m, g) => g.c > m.c ? g : m, op[0]) : null, worstPull = op.length ? op.reduce((m, g) => g.c < m.c ? g : m, op[0]) : null;
    h += '<div class="sg">' + sc('ALTIJD GEMIDDELDE', f2(S.avg), 'ongewogen', 1) + sc('HOOGSTE OOIT', fmt(S.max.c), esc(S.max.vak), 1) + sc('LAAGSTE OOIT', fmt(S.min.c), esc(S.min.vak), 1) + sc('CIJFERS', known, 'in totaal beschikbaar', 1) + '</div>';
    h += '<div class="sg">' + sc('🎴 PACKS GEOPEND', op.length, 'van ' + known) + sc('🔒 NOG TE OPENEN', Math.max(0, known - op.length)) + sc('⭐ 7+', S.n7, 'cijfers van 7,0 of hoger') + sc('💎 8+', S.n8, 'cijfers van 8,0 of hoger') + sc('🔥 9+', S.n9, 'cijfers van 9,0 of hoger') + sc('🌈 PERFECT', S.n10, 'exact 10,0')
      + (S.vakken.length >= 2 ? sc('📈 BESTE VAK', esc(S.vakken[0].v), f2(S.vakken[0].avg)) + sc('📉 MOEILIJKSTE VAK', esc(S.vakken[S.vakken.length - 1].v), f2(S.vakken[S.vakken.length - 1].avg)) : sc('📈 BESTE VAK', NA, '', 0, 1) + sc('📉 MOEILIJKSTE VAK', NA, '', 0, 1))
      + (S.dated >= 2 ? sc('🔥 LANGSTE REEKS', S.streak, `opeenvolgend ≥ ${fmt(streakMin)} · huidig ${S.curStreak}` + (S.dated < S.n ? ` · ${S.dated} van ${S.n} met datum` : '')) : sc('🔥 LANGSTE REEKS', NA, 'datums nodig (min. 2)', 0, 1))
      + (bestPull ? sc('🏆 BESTE PULL', fmt(bestPull.c), esc(bestPull.vak)) + sc('💀 SLECHTSTE PULL', fmt(worstPull.c), esc(worstPull.vak)) : '') + '</div>';
    h += '<div class="sh">⚖️ Ongewogen vs gewogen gemiddelde</div><div class="sg">' + sc('ONGEWOGEN GEMIDDELDE', f2(S.avg), S.n + ' cijfers')
      + (S.w ? sc('GEWOGEN GEMIDDELDE', f2(S.w.v), `${S.w.n} van ${S.n} cijfers met weging`) + sc('TOTAAL AANTAL WEGINGEN', String(S.w.sw).replace('.', ','), 'som van alle gewichten') : sc('GEWOGEN GEMIDDELDE', NA, 'geen wegingen gevonden', 0, 1)) + '</div>';
    h += '<div class="sh">📈 Gemiddelde per vak</div><div class="bars">' + S.vakken.map(x => bar(esc(x.v) + ' <small>(' + x.n + ')</small>', x.avg * 10, f2(x.avg) + (x.w ? '<br><small style="color:#9aa4d8;font-weight:600">gew. ' + f2(x.w.v) + '</small>' : ''))).join('') + '</div>';
    const byc = a.slice().sort((x, y) => y.c - x.c);
    h += '<div class="sh">🏆 Beste cijfers</div><div class="hl">' + byc.slice(0, 5).map(g => hrow(g)).join('') + '</div>';
    h += '<div class="sh">📉 Laagste cijfers</div><div class="hl">' + byc.slice(-5).reverse().map(g => hrow(g)).join('') + '</div>';
    h += '<div class="sh">🎴 Rarity-verdeling</div><div class="bars">' + R.map((x, i) => bar(x[1], S.n ? S.rar[i] / S.n * 100 : 0, S.rar[i], x[2])).join('') + '</div>';
    const BL = ['< 5,5', '5,5–6,9', '7,0–7,9', '8,0–8,9', '9,0–9,9', '10,0'], mx = Math.max(1, ...S.bands);
    h += '<div class="sh">📊 Cijferverdeling</div><div class="bars">' + BL.map((l, i) => bar(l, S.bands[i] / mx * 100, S.bands[i])).join('') + '</div>';
    h += '<div class="sh">🕓 Cijfergeschiedenis</div>';
    if (S.months.length >= 2) {
      h += '<div class="bars">' + S.months.map(m => { const p = m.k.split('-'); return bar(DNL[+p[1] - 1] + ' ' + p[0] + ' <small>(' + m.n + ')</small>', m.avg * 10, f2(m.avg)); }).join('') + '</div>';
      const d = S.months[S.months.length - 1].avg - S.months[0].avg;
      h += `<div class="snote">${d > 0.05 ? '📈 Je gemiddelde is gestegen' : d < -0.05 ? '📉 Je gemiddelde is gedaald' : '➡️ Je gemiddelde is stabiel'} (${fd(d)} sinds ${DNL[+S.months[0].k.split('-')[1] - 1]}).` + (S.dated < S.n ? ` Gebaseerd op ${S.dated} van ${S.n} cijfers met datum.` : '') + '</div>';
    } else h += `<div class="snote">${NA}: er zijn cijfers uit minstens 2 maanden met een datum nodig.</div>`;
    h += '<div class="sh">🏅 Persoonlijke records</div>' + (rec ? '<div class="sg">' + sc('HOOGSTE CIJFER', rec.best ? fmt(rec.best) : '–') + sc('HOOGSTE GEMIDDELDE', rec.avg ? f2(rec.avg) : '–') + sc('LANGSTE REEKS', rec.streak || '–') + '</div>' : `<div class="snote">Nog geen records. Die worden bijgehouden zodra je packs opent.</div>`);
    v.innerHTML = h;
  }
  function renderHist() {
    const v = $('histView'), op = openedList();
    if (!op.length) { v.innerHTML = '<div class="empty">Nog geen packs geopend.</div>'; return; }
    const top = op.slice().sort((x, y) => y.c - x.c).slice(0, 3), md = ['🥇', '🥈', '🥉'];
    const hist = op.slice().sort((x, y) => (y.t || 0) - (x.t || 0) || y.c - x.c);
    v.innerHTML = '<div class="sh" style="margin-top:14px">🏆 Beste pulls</div><div class="hl">' + top.map((g, i) => hrow(g, md[i])).join('') + '</div>' +
      '<div class="sh">🕘 Pack history</div><div class="hl">' + hist.map(g => hrow(g)).join('') + '</div>';
  }
  function showDetail(id) {
    const g = cards[id]; if (!g) return;
    const r = rar(g.c), it = items.find(i => i.id === id);
    const info = [g.oms ? esc(g.oms) : '', g.weging ? 'Gewicht: ' + esc(g.weging) : '', g.d ? fmtDate(g.d) : '', g.t ? 'Geopend op ' + new Date(g.t).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' }) : ''].filter(Boolean).join('<br>');
    $('detail').innerHTML = `<div><div class="dc" style="background:${r[3]};color:${r[4]}"><div class="t">${emo(g.vak)} ${esc(g.vak)}</div><div><div class="n">${fmt(g.c)}</div><div class="b">${r[0] === 'perfect' ? '★ PERFECT ★' : r[1]}</div></div><div class="i">${info || '&nbsp;'}</div></div>` +
      `<div class="btns dbtn">${it ? `<button data-dact="replay" data-id="${id}">▶ Opnieuw afspelen</button>` : ''}<button class="pri" data-dact="close">Sluiten</button></div></div>`;
    $('detail').className = 'on';
  }

  function applyTab() {
    const V = { packs: 'packsView', squad: 'squadView', stats: 'statsView', hist: 'histView' }, T = { packs: 'tPacks', squad: 'tSquad', stats: 'tStats', hist: 'tHist' };
    Object.keys(V).forEach(k => { $(V[k]).style.display = tab === k ? '' : 'none'; $(T[k]).classList.toggle('on', tab === k); });
    if (tab === 'squad') renderSquad(); else if (tab === 'stats') renderStats(); else if (tab === 'hist') renderHist();
  }
  const saveSquad = () => store.saveSquad();

  const openPanel = () => { refresh(); $('panel').className = 'on'; };
  const closePanel = () => { $('panel').className = ''; $('menu').className = ''; };
  $('fab').onclick = openPanel;
  $('tPacks').onclick = () => { tab = 'packs'; pickSlot = null; applyTab(); };
  $('tSquad').onclick = () => { tab = 'squad'; pickSlot = null; applyTab(); };
  $('tStats').onclick = () => { tab = 'stats'; applyTab(); };
  $('tHist').onclick = () => { tab = 'hist'; applyTab(); };
  $('statsView').onclick = e => {
    const b = e.target.closest('[data-basis]'); if (b) { statsAll = b.dataset.basis === 'a'; store.savePrefs(); return renderStats(); }
    const d = e.target.closest('[data-det]'); if (d) showDetail(d.dataset.det);
  };
  $('histView').onclick = e => { const d = e.target.closest('[data-det]'); if (d) showDetail(d.dataset.det); };
  $('detail').onclick = e => {
    const a = e.target.closest('[data-dact]');
    if (a && a.dataset.dact === 'replay') { const it = items.find(i => i.id === a.dataset.id); $('detail').className = ''; if (it) startPack(it); return; }
    if (a || e.target === $('detail')) $('detail').className = '';
  };
  $('mMode').onclick = e => { e.stopPropagation(); mode = mode === 'cin' ? 'quick' : mode === 'quick' ? 'inst' : 'cin'; store.savePrefs(); labels(); };
  $('mStk').onclick = e => { e.stopPropagation(); streakMin = STK[(STK.indexOf(streakMin) + 1) % STK.length]; store.savePrefs(); labels(); if (tab === 'stats') renderStats(); };
  $('squadView').onclick = e => {
    const t = e.target.closest('[data-slot],[data-pick],[data-act]'); if (!t) return;
    if (t.dataset.slot !== undefined) { pickSlot = +t.dataset.slot; return renderSquad(); }
    if (t.dataset.pick) {
      const i = pickSlot, id = t.dataset.pick, j = squad.s.indexOf(id);
      if (j >= 0 && j !== i) squad.s[j] = squad.s[i] || null;
      squad.s[i] = id; pickSlot = null; saveSquad(); tone(880, 0, .12, 'triangle', .08); return renderSquad();
    }
    const a = t.dataset.act;
    if (a === 'cancel') pickSlot = null;
    else if (a === 'remove') { squad.s[pickSlot] = null; pickSlot = null; saveSquad(); }
    else if (a === 'clear') { squad.s = Array(11).fill(null); saveSquad(); }
    else if (a === 'auto') {
      const top = cardList().slice(0, 11).map(g => g.id);
      squad.s = Array.from({ length: 11 }, (_, k) => top[k] || null); saveSquad();
      [523, 659, 784, 1047].forEach((f, k) => tone(f, k * .07, .35, 'triangle', .1));
    }
    renderSquad();
  };
  $('squadView').onchange = e => { if (e.target.id === 'fsel' && FORM[e.target.value]) { squad.f = e.target.value; saveSquad(); renderSquad(); } };
  try { chrome.runtime.onMessage.addListener((m, _s, reply) => { if (m && m.t === 'open') { openPanel(); try { reply({ ok: true }); } catch (e) {} } }); } catch (e) {}
  $('x').onclick = closePanel;
  $('panel').onclick = e => {
    if (e.target === $('panel')) return closePanel();
    if (!e.target.closest('#menu') && !e.target.closest('#gear')) $('menu').className = '';
    const t = e.target.closest('[data-i]');
    if (t && items[+t.dataset.i]) startPack(items[+t.dataset.i]);
  };
  $('gear').onclick = e => { e.stopPropagation(); $('menu').classList.toggle('on'); };
  const toggleSound = e => { e.stopPropagation(); muted = !muted; store.savePrefs(); labels(); if (!muted) { ac(); tone(880, 0, .15, 'sine', .1); } };
  $('hSnd').onclick = toggleSound; $('mSnd').onclick = toggleSound; $('snd2').onclick = toggleSound;
  $('mShd').onclick = () => { shieldOn = !shieldOn; store.savePrefs(); labels(); shield(); };
  $('reset').onclick = e => {
    const b = e.currentTarget;
    if (!armed) { armed = 1; b.textContent = '⚠️ Klik nogmaals om alles te wissen'; setTimeout(() => { armed = 0; b.textContent = '↺ Opnieuw beginnen'; }, 3000); }
    else { armed = 0; b.textContent = '↺ Opnieuw beginnen'; opened = new Set(); cards = {}; rec = null; PULL = null; squad = { f: squad.f, s: Array(11).fill(null) }; pickSlot = null; store.saveOpened(); store.saveCards(); store.saveSquad(); store.saveRec(); $('menu').className = ''; refresh(); }
  };
  skipBtn.onclick = () => { if (!finalShown) skipAnim(); else { afterFast = true; if (skipWake) skipWake(); } };
  $('sx').onclick = () => closeStage(finalShown);
  $('bSee').onclick = () => closeStage(true);
  $('bStats').onclick = () => closeStage(true, 'stats');
  $('bNext').onclick = () => { const nx = items.findIndex(i => !opened.has(i.id)); if (nx >= 0) startPack(items[nx]); };
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && stage.classList.contains('on')) { e.stopPropagation(); finalShown ? closeStage(true) : skipAnim(); }
  }, true);

  // ---------- start ----------
  labels();
  store.load().then(d => {
    opened = new Set(d.opened || []);
    cards = (d.cards && typeof d.cards === 'object') ? d.cards : {};
    if (d.squad && FORM[d.squad.f]) squad = { f: d.squad.f, s: Array.from({ length: 11 }, (_, k) => (d.squad.s && d.squad.s[k]) || null) };
    if (d.prefs) {
      muted = !!d.prefs.muted; shieldOn = d.prefs.shieldOn !== false; statsAll = !!d.prefs.statsAll;
      if (MODES[d.prefs.mode]) mode = d.prefs.mode; if (STK.includes(d.prefs.streakMin)) streakMin = d.prefs.streakMin;
    }
    rec = d.rec && typeof d.rec === 'object' ? d.rec : null;
    labels(); shield();
  });
})();
